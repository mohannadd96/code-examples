<?php 
class User{
	private $iduser;
	private $nom;
	private $prenom;
	private $mdp;
	private $rmdp;
	private $email;
	private $role;
	function __construct($nom,$prenom,$mdp,$rmdp,$email,$role){
		$this->nom=$nom;
		$this->prenom=$prenom;
		$this->mdp=$mdp;
		$this->rmdp=$rmdp;
		$this->email=$email;
		$this->role=$role;
	}
	function getnom(){
		return $this->nom;
	}
	function getprenom(){
		return $this->prenom;
	}
	function getmdp(){
		return $this->mdp;
	}
	function getrmdp(){
		return $this->rmdp;
	}
	function getemail(){
		return $this->email;
	}
	function getiduser(){
		return $this->iduser;
	}
	function getrole(){
		return $this->role;
	}

	function setname($nom){
		$this->nom=$nom;
	}
	function setprenom($prenom){
		$this->prenom=$prenom;
	}
	function setmdp($mdp){
		$this->mdp=$mdp;
	}
	function setrmdp($rmdp){
		$this->rmdp=$rmdp;
	}
	function setemail($email){
		$this->email=$email;
	}
	function setiduser($iduser){
		$this->iduser=$iduser;
	}
	function setrole($role){
		$this->role=$role;
	}

    
}
 ?>