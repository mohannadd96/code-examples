<?php 
class Rapport{
	private $idrapport;
	private $titre;
	private $annee;
	private $etudiant;
	private $valide;
	private $rapport;
	private $note;
	function __construct($titre,$annee,$note,$etudiant,$valide,$rapport){
		$this->titre=$titre;
		$this->annee=$annee;
		$this->etudiant=$etudiant;
		$this->valide=$valide;
		$this->rapport=$rapport;
		$this->note=$note;
	}
	function gettitre(){
		return $this->titre;
	}
	function getannee(){
		return $this->annee;
	}
	function getetudiant(){
		return $this->etudiant;
	}
	function getidrapport(){
		return $this->idrapport;
	}
	function getvalide(){
		return $this->valide;
	}
	function getrapport(){
		return $this->rapport;
	}
	function getnote(){
		return $this->note;
	}

	function setnote($note){
		$this->note=$note;
	}
	function settitre($titre){
		$this->titre=$titre;
	}
	function setannee($annee){
		$this->annee=$annee;
	}
	function setetudiant($etudiant){
		$this->etudiant=$etudiant;
	}
	function setidrapport($idrapport){
		$this->idrapport=$idrapport;
	}
	function setvalide($valide){
		$this->valide=$valide;
	}
	function setrapport($rapport){
		$this->rapport=$rapport;
	}
    
}
 ?>