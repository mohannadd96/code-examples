<?PHP
include "../core/Frapport.php";
$Frapport=new Frapport();
if (isset($_POST["feed_id"])){
	$Frapport->supprimerrapport($_POST["feed_id"]);
	
}

?>