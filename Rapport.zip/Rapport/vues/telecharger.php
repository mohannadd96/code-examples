<?php
if (isset($_POST["nomrapport"])){
$file = "http://localhost/Rapport/uploads/". $_POST["nomrapport"] .""; 

header("Content-Description: File Transfer"); 
header("Content-Type: application/pdf"); 
header("Content-Disposition: attachment; filename=". $_POST["nomrapport"] .""); 

readfile ($file);
header("Refresh:1 url=ok.php");
}
?>