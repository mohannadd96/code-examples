<?php

include "../classes/rapport.php";
include "../core/Frapport.php";

if(isset($_POST['pid']) && isset($_POST['stars'])){


     $rapport1C=new Frapport();
     $rapport1C->ajoutnote($_POST['pid'],$_POST['stars']);
}

if(isset($_POST['pid2']) && isset($_POST['stars2'])){


     $rapport1C=new Frapport();
     $rapport1C->ajoutnote2($_POST['pid2'],$_POST['stars2']);
}

?>