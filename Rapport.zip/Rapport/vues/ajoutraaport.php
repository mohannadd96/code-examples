<?php 
include "../classes/rapport.php";
include "../core/Frapport.php";
session_start();

$host="localhost";
$user="root";
$password="";
$db="rapport";
 
$con = mysqli_connect($host,$user,$password,$db);

if (isset($_POST['titre']) and isset($_POST['annee']) and isset($_POST['etudiant'])) 
{
	$titre=$_POST['titre'];
    $annee=$_POST['annee'];
    $id=$_POST['id'];
	$etudiant=1;
 
    $role=1;
     $valide=0;


    //directory pour les fichiers ( rapports ) uploaded
    $uploaddir = '../uploads/';
    //le fichier
    $uploadfile = $uploaddir . basename($_FILES['rapportpdf']['name']);
    //nom du fichier
    $rapport =$_FILES['rapportpdf']['name'];


    //l upload du fichier
    if (move_uploaded_file($_FILES['rapportpdf']['tmp_name'], $uploadfile)) {
    echo "File is valid, and was successfully uploaded.\n";
    } else {
        echo "Possible file upload attack!\n";
    }

    echo 'Here is some more debugging info:';
    print_r($_FILES);


	// constructeur rapport
     $rapport1=new Rapport($_POST['titre'],$_POST['annee'],$id,$valide,$rapport);
     $rapport1C=new Frapport();
     $rapport1C->ajouterrapport($rapport1);
     header('Location: accueil.php');
	
}
else
{
	echo "vérifier les champs";
}
//*/


?>