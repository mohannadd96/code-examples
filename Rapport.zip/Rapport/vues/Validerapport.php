<?PHP
include "../core/Frapport.php";
$Frapport=new Frapport();
if (isset($_POST["feed_idd"])){
	$Frapport->modifierrapport($_POST["feed_idd"]);
	
	
}

?>