    <?php 
    include "../classes/user.php";
    include "../core/Fuser.php";
    session_start();

    $host="localhost";
    $user="root";
    $password="";
    $db="rapport";

    $con = mysqli_connect($host,$user,$password,$db);

    if (isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['mdp']) and isset($_POST['rmdp']) and isset($_POST['email']) and isset($_POST['role']) ) 
    {
    $nom=$_POST['nom'];
    $prenom=$_POST['prenom'];
    $mdp=$_POST['mdp'];
    $rmdp=$_POST['rmdp'];
    $email=$_POST['email'];
    $role=1;

    //verfier les champs vide
    if(empty($nom) || empty($prenom) || empty($mdp) || empty($rmdp) || empty($email)  )
    {
    	header('Location: register.php');
    	exit();
    }

    else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) 
    {
    	header('Location: register.php');
    	exit();
    }

    //verifier se les deux mdp match
    else if( $mdp != $rmdp )
    {
    	header('Location: register.php');
    	exit();
    }

    //deffenir le role
    if ($_POST['role']==2)
    {
    $role=2;
    }
    else if ($_POST['role']==3)
    {
    $role=3;
    }
    //verfier si l'email exist ou non
    else {
        $sql = "SELECT email FROM user WHERE email='".$email."' ";
        $stmt = mysqli_stmt_init($con);
        if (!mysqli_stmt_prepare($stmt, $sql)) {

            header('Location: register.php?error=sqlerror');
        exit();
        } 
        else 
        {
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $resultcheck = mysqli_stmt_num_rows($stmt);
            if ($resultcheck > 0) {
                echo "<script type=\"text/javascript\">window.alert('email est deja utilisé');
        window.location.href = 'register.php?error=emailalreadytaken';</script>"; 
              //  header('Location: register.php?error=emailalreadytaken');
                exit();
                
            }

        }


    }



     $client1=new User($_POST['nom'],$_POST['prenom'],$_POST['mdp'],$_POST['rmdp'],$_POST['email'],$role);
     $client1C=new Fuser();
     $client1C->ajouteruser($client1);
     $_SESSION['mail']=$email;
     header('Location: accueil.php');

    }
    else
    {
    echo "vérifier les champs";
    }
    //*/


    ?>