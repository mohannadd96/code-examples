<!DOCTYPE html>
<?php
include "functions.php";
session_start();
if(logged_in())
{
header("location:index.php");
}
$host="localhost";
$user="root";
$password="";
$db="rapport";

$con = mysqli_connect($host,$user,$password,$db);
$emaill=$_SESSION['mail'];

//Get le user actuel 

$result=mysqli_query($con , "SELECT nom,prenom,iduser,role FROM user WHERE email='$emaill'");
$retrive=mysqli_fetch_array($result);
//print_r($retrive);
$name=$retrive['nom'];
$id=$retrive['iduser'];
$lname=$retrive['prenom'];

//Defenir le role

if ($retrive['role']==1)
{
$role="ADMIN";
}
if ($retrive['role']==2)
{
$role="Prof";
}
if ($retrive['role']==3)
{
$role="Etudiant";
}

$conn=mysqli_connect("localhost","root","","rapport");
    // Check connection
if (mysqli_connect_errno()){
echo "Failed to connect to MySQL: " . mysqli_connect_error();
die();
}

?>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta name="description" content="" />
<meta name="author" content="" />
<title>Accueil</title>
<!-- Favicon-->
<link rel="icon" type="image/x-icon" href="assets/img/logos.png" />
<!-- Bootstrap icons-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" type="text/css" />
<!-- Google fonts-->
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css" />
<!-- Core theme CSS (includes Bootstrap)-->
<link href="css/styles.css" rel="stylesheet" />
<link href="css/table.css" rel="stylesheet" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
 <script src="//lab.subinsb.com/projects/Francium/star/Fr.star.js"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.0/css/jquery.dataTables.min.css">
<style type="text/css">
	#demo {
  display: grid;
  grid-template-columns: auto auto;
  grid-gap: 10px;
  font-family: arial, sans-serif;
}
.pdt {
  background: #fafafa;
  border: 1px solid #ddd;
  padding: 10px;
}
.pname {
  font-weight: bold;
  font-size: 1.3em;
}
.pprice, .prate {
  color: #777;
}
.pstar img {
  width: 20px;
  cursor: pointer;
}
.pstarn img {
  width: 20px;
  cursor: pointer;
}
.p2star img {
  width: 20px;
  cursor: pointer;
}
</style>
</head>
<body>
<!-- Navigation-->
<nav class="navbar navbar-light bg-light static-top">
	<div class="container">
		<a class="navbar-brand brand-logo-mini">
			<img src="assets/img/LOGO.jpg" alt="logo" style=" width: 100px; height: 41px;"> 
		</a>
		<p>Bienvenu <a href="#"><?php echo $name;?></a>, Role : <?php echo $role;?> <a class="btn btn-primary" href="Logout.php">Déconnect</a></p>
	</div>
</nav>
<!-- Masthead-->

<section class="call-to-action text-white text-center" id="signup">
	<div class="container position-relative">
		<div class="row justify-content-center">
			<div class="col-xl-6">
				<h2 class="mb-4">Recherche de ton rapport</h2>
				<form class="form-subscribe">
					<!-- Email address input-->
					<div class="row">
						<div class="col">
							<input class="form-control form-control-lg dataTables_filter"  id="myinput" type="search" placeholder="Taper quelque chose ..."  />

						</div>

					</div>

				</form>
			</div>
		</div>
	</div>
</section>

<!-- Icons Grid-->
<section class="features-icons bg-light text-center" style="padding-top: 0rem;">
	<div class="container-xl">
		<div class="table-responsive">
			<div class="table-wrapper">
				<div class="table-title">
					<div class="row">
						<div class="col-sm-6">
							<h2>Gestion <b>Rapport</b></h2>
						</div>
						<div class="col-sm-6">
							<a href="#ajoutrapportModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Ajout rapport</span></a>					
						</div>
					</div>
				</div>
				<?PHP
				include "../core/Frapport.php";

			//Lister les rapports

				$rapport=new Frapport(); 
				$listerapport=$rapport->afficherrapports();

//var_dump($listeEmployes->fetchAll());
				?>
				<table id="example" class="table table-striped table-hover">
					<thead>
						<tr>
							<th>

							</th>
							<th>Titre</th>
							<th>Date</th>
							<th>Etudiant</th>
							<th>Note</th>
							<th>Note2</th>
							<th>Status</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						<?PHP  
						$sql = "SELECT * FROM rapport ";
						$res_data = mysqli_query($conn,$sql);
						while($row = mysqli_fetch_array($res_data)){
							$idd=$row['etudiant'];
							//Get le user qui met le rapport depuis son id ' idd '
							$result1=mysqli_query($con , "SELECT nom,prenom FROM user WHERE iduser='$idd'");
							$retrive1=mysqli_fetch_array($result1);
							?>
							<tr>
								<td>
									<span class="custom-checkbox">
										<input type="checkbox" id="checkbox1" name="options[]" value="1">
										<label for="checkbox1"></label>
									</span>
								</td>
								<td><?PHP echo $row['titre']; ?></td>
								<td><?PHP echo $row['annee']; ?></td>
								<td><?PHP echo $retrive1['prenom']; ?> <?PHP echo $retrive1['nom']; ?></td>
								<?php if ($role=="Prof") { ?>
								<td><div class="pstar" data-pid="<?php echo $row['idrapport']; ?>">
								Note 1: <?php
								$rate = isset($row['note']) ? $row["note"] : 0 ;
								for ($i=1; $i<=5; $i++) {
								  $img = $i<=$rate ? "star" : "star-blank" ;
								  echo "<img src='$img.png' data-set='$i'>";
								}
								?></div></td>
								<td><div class="p2star" data-pid="<?php echo $row['idrapport']; ?>">
								Note 2: <?php
								$rate = isset($row['note2']) ? $row["note2"] : 0 ;
								for ($i=1; $i<=5; $i++) {
								  $img = $i<=$rate ? "star" : "star-blank" ;
								  echo "<img src='$img.png' data-set='$i'>";
								}
								?></div></td>
								<?php } else {?>
									<td><div class="pstarn" data-pid="<?php echo $row['idrapport']; ?>">
								<?php
								$rate = isset($row['note']) ? $row["note"] : 0 ;
								for ($i=1; $i<=5; $i++) {
								  $img = $i<=$rate ? "star" : "star-blank" ;
								  echo "<img src='$img.png' data-set='$i'>";
								}
								?></div></td>
									<td><div class="pstarn" data-pid="<?php echo $row['idrapport']; ?>">
								Note 2: <?php
								$rate = isset($row['note2']) ? $row["note2"] : 0 ;
								for ($i=1; $i<=5; $i++) {
								  $img = $i<=$rate ? "star" : "star-blank" ;
								  echo "<img src='$img.png' data-set='$i'>";
								}
								?></div></td>
									<?php }?>
								<?php if ($row['valide'] == 0) { ?>
									<td><span class="status text-fail">&bull;</span>Non Validé</td>
								<?php } else {?>
									<td><span class="status text-success">&bull;</span>Validé</td>
								<?php }?>
								<td>
									 <?php if ($role!="Etudiant") { ?>
									 	<a href="#ValiderModal" data-id="<?php echo $row['idrapport']; ?>" class="edit" data-toggle="modal"><i class="fa fa-check-square" style="font-size:20px" data-toggle="tooltip" title="Valider"></i></a>	
									 	<a  href="http://localhost/Rapport/uploads/<?php echo $row['rapport']; ?>" download class="download"><i class="fa fa-download" style="font-size:20px" title="Telecharger"></i></a>
								<?php } ?>
									<?php if ($role=="Etudiant" && $row['valide'] == 1) { ?>
									<a  href="http://localhost/Rapport/uploads/<?php echo $row['rapport']; ?>" download class="download"><i class="fa fa-download" style="font-size:20px" title="Telecharger"></i></a>
									<?php } else if($role=="Etudiant" && $row['valide'] == 0) {?>
									<span class="status text-fail">Pas encore validé pour télécharger </span>
								<?php } ?>
									<?php if ($role=="ADMIN") { ?>
									 	<a href="#suprimraaportModal" data-id="<?php echo $row['idrapport']; ?>" class="delete" data-toggle="modal"><i class="fa fa-trash" style="font-size:20px" data-toggle="tooltip" title="Supprimer"></i></a>
								<?php } ?>
								</td>
							</tr>
							<?PHP
						}
						mysqli_close($conn);

						?>
					</tbody>
				</table>
				
			</div>
		</div>        
	</div>
	<!-- ajout rapport Modal HTML -->
	<div id="ajoutrapportModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form action="ajoutraaport.php" method="post" enctype="multipart/form-data">
					<input id="feed_id" name="feed_id" value="" type="hidden" />
					<div class="modal-header">						
						<h4 class="modal-title">Ajout rapport</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<div class="form-group">
							<label>Titre</label>
							<input type="text" class="form-control" name="titre" required>
						</div>
						<div class="form-group">
							<label>Annee</label>
							<input type="date" class="form-control" name="annee" required>
						</div>
						<div class="form-group">
							<label>Etudiant</label>
							<input class="form-control" type="text" name="etudiant" value="<?php echo $name; ?>" readonly></input>
						</div>
						<input class="form-control"  name="id" value="<?php echo $id; ?>" type="hidden"></input>
						<div class="form-group">
							<label>Votre rapport</label>
							<input type="file" class="form-control" name="rapportpdf" required>
						</div>					
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-success" value="Ajout">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- valide rapport Modal HTML -->
	<div id="ValiderModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form action="Validerapport.php" method="post">
					<input id="feed_idd" name="feed_idd" value="" type="hidden" />
					<div class="modal-header">						
						<h4 class="modal-title">Valider Rapport</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<p>Vous êtes sûr que tu va Valider le rapport?</p>
						<p class="text-warning"><small>Cette action ne peut pas être annulée.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-primary" value="Valider">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="suprimraaportModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form action="suprimrapport.php" method="post">
					<input id="feed_id" name="feed_id" value="" type="hidden" />
					<div class="modal-header">						
						<h4 class="modal-title">Supprimer Rapport</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<p>Vous êtes sûr que tu va supprimer le rapport?</p>
						<p class="text-warning"><small>Cette action ne peut pas être annulée.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-danger" value="Supprimer">
					</div>
				</form>
				<form id="ninForm" method="post" action="ajoutnote.php">
 					 <input id="ninPdt" type="hidden" name="pid"/>
 					 <input id="ninStar" type="hidden" name="stars"/>
				</form>
				<form id="ninForm2" method="post" action="ajoutnote.php">
 					 <input id="ninPdt2" type="hidden" name="pid2"/>
 					 <input id="ninStar2" type="hidden" name="stars2"/>
				</form>
			</div>
		</div>
	</div>
</section>

<!-- Footer-->

<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<!-- * *                               SB Forms JS                               * *-->
<!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
<script>
	//populé le modele delete avec l id de rapport
	$(document).ready(function () {
		$('body').on('click', '.delete',function(){
			document.getElementById("feed_id").value = $(this).attr('data-id');
			console.log($(this).attr('data-id'));
		});
	});
	//populé le modele valider avec l id de rapport
	$(document).ready(function () {
		$('body').on('click', '.edit',function(){
			document.getElementById("feed_idd").value = $(this).attr('data-id');
			console.log($(this).attr('data-id'));
		});
	});
</script>
<script>
	//des fonctions predefinis qui gere le datatable des rapport avec le (pagination,recherche etc ...)
	$(document).ready(function() {

var table = $('#example').DataTable(
{ language: {
    url: 'https://cdn.datatables.net/plug-ins/3cfcc339e89/i18n/French.json',
  }
})

  $('#myinput').on( 'keyup', function () {
table.search( this.value ).draw();
} );

} );

</script>
<script type="text/javascript">
	var stars = {
  // (A) INIT - ATTACH CLICK & HOVER EVENMENT POUR LES STARS note1
  init : function () {
    for (let docket of document.getElementsByClassName("pstar")) {
      for (let star of docket.getElementsByTagName("img")) {
        star.addEventListener("mouseover", stars.hover);
        star.addEventListener("click", stars.click);
      }
    }
  },

  // (B) HOVER - Mise a jour num de star jaune
  hover : function () {
    let all = this.parentElement.getElementsByTagName("img"),
        set = this.dataset.set,
        i = 1;
    for (let star of all) {
      star.src = i<=set ? "star.png" : "star-blank.png";
      i++;
    }
  },
  
  // (C) CLICK - SUBMIT FORM
  click : function () {
    document.getElementById("ninPdt").value = this.parentElement.dataset.pid;
    document.getElementById("ninStar").value = this.dataset.set;
    document.getElementById("ninForm").submit();
  }
};
	var stars2 = {
  // (A) INIT - ATTACH CLICK & HOVER EVENMENT POUR LES STARS note2
  init : function () {
    for (let docket of document.getElementsByClassName("p2star")) {
      for (let star of docket.getElementsByTagName("img")) {
        star.addEventListener("mouseover", stars2.hover);
        star.addEventListener("click", stars2.click);
      }
    }
  },

  // (B) HOVER - Mise a jour num de star jaune
  hover : function () {
    let all = this.parentElement.getElementsByTagName("img"),
        set = this.dataset.set,
        i = 1;
    for (let star of all) {
      star.src = i<=set ? "star.png" : "star-blank.png";
      i++;
    }
  },
  
  // (C) CLICK - SUBMIT FORM
  click : function () {
    document.getElementById("ninPdt2").value = this.parentElement.dataset.pid;
    document.getElementById("ninStar2").value = this.dataset.set;
    document.getElementById("ninForm2").submit();
  }
};
window.addEventListener("DOMContentLoaded", stars.init);
window.addEventListener("DOMContentLoaded", stars2.init);
</script>
</body>
</html>
