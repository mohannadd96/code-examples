<?php 
include "../classes/User.php";
include "../core/Fuser.php";

session_start();
$host="localhost";
$user="root";
$password="";
$db="rapport";
 
$con = mysqli_connect($host,$user,$password,$db);

 
	$email = $_POST['email'];
	$password = $_POST['mdp'];


		//verifier si le user exist
	  $check = mysqli_query($con,'SELECT * from user where email = "'.$email.'" && mdp = "'.$password.'" ');
	$c = mysqli_fetch_array($check);
	
	if($c){
		//creer le session
					$_SESSION['mail']=$email;

header('Location: accueil.php');
		
		}
	else{
		echo "<script type=\"text/javascript\">window.alert('password invalid');
        window.location.href = 'index.php';</script>"; 
       // header("Location:pages-signin.php");
        exit();
		}
?>