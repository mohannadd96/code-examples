<?php
function searchFiles($needle, $haystack){
    $found = array();
    $FILES = scandir($haystack);
    $dir = dir($haystack);
     while (false !== ($files = $dir->read()))
{   

        if (is_file($haystack . '/' . $files))
    {
            $content = file_get_contents($haystack."/".$files);
            if(strpos($content, $needle) !== false) array_push($found, $files);
        }
      
    }
    return $found;
}

$files = searchFiles("java", "../uploads");
echo "<script>console.log('" . json_encode($files) . "');</script>";

?>