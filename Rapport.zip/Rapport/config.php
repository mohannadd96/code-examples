<?php
  @session_start();

  $con = mysqli_connect('localhost','root','','rapport');


  if(!$con){
    echo "not connected";
    }
    else "connected";
  
  if(@$_SESSION['userid']!="")
  {
   $loggedinuserinfo = mysqli_query($con,'SELECT * from user where id = "'.$_SESSION['userid'].'"');
   $lui = mysqli_fetch_array($loggedinuserinfo);
  }

  class config {
    private static $instance = NULL;
    
    public static function getConnexion() {
      if (!isset(self::$instance)) {
		try{
        self::$instance = new PDO('mysql:host=localhost;dbname=rapport', 'root', '');
		self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}catch(Exception $e){
            die('Erreur: '.$e->getMessage());
		}
      }
      return self::$instance;
    }

        function afficheruser(){
    $sql="SElECT * From rapport";
    $db = config::getConnexion();
    try{
    $liste=$db->query($sql);
    return $liste;
    }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        } 
  }
  }
?>