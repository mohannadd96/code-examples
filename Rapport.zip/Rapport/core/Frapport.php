<?php 
include "../config.php";
class Frapport{

    function afficherrapport ($rapport){
		echo "titre : ".$rapport->gettitre()."<br>";
		echo "annee: ".$rapport->getannee()."<br>";
		echo "etudiant: ".$rapport->getetudiant()."<br>";
		echo "valide: ".$rapport->getvalide()."<br>";
	}
		function afficherrapports(){
		$sql="SElECT * From rapport";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

	function ajouterrapport($rapport){
		$sql="insert into rapport (titre,annee,etudiant,note,valide,rapport) values (:titre,:annee,:etudiant,:note,:valide,:rapport)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $titre=$rapport->gettitre();
        $annee=$rapport->getannee();
        $etudiant=$rapport->getetudiant();
        $valide=$rapport->getvalide();
        $rapport=$rapport->getrapport();
        $note=$rapport->getnote();
		$req->bindValue(':titre',$titre);
		$req->bindValue(':annee',$annee);
		$req->bindValue(':etudiant',$etudiant);
		$req->bindValue(':valide',$valide);
		$req->bindValue(':rapport',$rapport);
		$req->bindValue(':note',$rapport);
		
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}

function modifierrapport($idrapport){
		$sql="UPDATE rapport SET valide=:valide WHERE idrapport= :idrapport ";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
	try{		
        $req=$db->prepare($sql);       
        $valide=1;		
		$req->bindValue(':valide',$valide);
		$req->bindValue(':idrapport',$idrapport);
			
            $s=$req->execute();			
            header("Refresh:0 url=accueil.php");
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
 
        }
		
	}

	function ajoutnote($idrapport,$note){
		$sql="UPDATE rapport SET note=:note WHERE idrapport= :idrapport ";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
	try{		
        $req=$db->prepare($sql);       ;		
		$req->bindValue(':note',$note);
		$req->bindValue(':idrapport',$idrapport);
			
            $s=$req->execute();			
            header("Refresh:0 url=accueil.php");
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
 
        }
		
	}
	function ajoutnote2($idrapport,$note2){
		$sql="UPDATE rapport SET note2=:note2 WHERE idrapport= :idrapport ";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
	try{		
        $req=$db->prepare($sql);       ;		
		$req->bindValue(':note2',$note2);
		$req->bindValue(':idrapport',$idrapport);
			
            $s=$req->execute();			
            header("Refresh:0 url=accueil.php");
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
 
        }
		
	}

	function supprimerrapport($idrapport){
		$sql="DELETE FROM rapport where idrapport= :idrapport";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':idrapport',$idrapport);
		try{
            $req->execute();
           // header('Location: index.php');
            header("Refresh:0 url=accueil.php");
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

 ?>

