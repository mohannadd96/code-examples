<?php 
include "../config.php";
class Fuser{

    function afficheruser ($user){
		echo "nom : ".$user->getnom()."<br>";
		echo "prenom: ".$user->getprenom()."<br>";
		echo "mot de passe: ".$user->getmdp()."<br>";
		echo "r mot de passe: ".$user->getrmdp()."<br>";
		echo "email: ".$user->getemail()."<br>";
		echo "role: ".$user->getrole()."<br>";
	}
		function afficherusers(){
		$sql="SElECT * From user";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

	function ajouteruser($user){
		$sql="insert into user (nom,prenom,mdp,rmdp,email,role) values (:nom,:prenom,:mdp,:rmdp,:email,:role)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $nom=$user->getnom();
        $prenom=$user->getprenom();
        $mdp=$user->getmdp();
        $rmdp=$user->getrmdp();
        $email=$user->getemail();
        $role=$user->getrole();
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':mdp',$mdp);
		$req->bindValue(':rmdp',$rmdp);
		$req->bindValue(':email',$email);
		$req->bindValue(':role',$role);
		
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}

function modifieruser($user,$email){
		$sql="UPDATE user SET nom=:nom,prenom=:prenom,mdp=:mdp,rmdp=:rmdp,role=:role,email=:email WHERE email=:email ";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
        $nom=$user->getnom();
        $prenom=$user->getprenom();
        $mdp=$user->getmdp();
        $rmdp=$user->getrmdp();
        $role=$user->getrole();
        $eemail=$user->getemail();
		$datas = array(':nom'=>$nom,':prenom'=>$prenom,':mdp'=>$mdp,':rmdp'=>$rmdp,':role'=>$role,':email'=>$email);
		
        $req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':mdp',$mdp);
		$req->bindValue(':rmdp',$rmdp);
		$req->bindValue(':role',$role);
		$req->bindValue(':email',$email);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
		function recupereruser($emaill){
		$sql="SELECT * from user where email=$emaill";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function supprimeruser($email){
		$sql="DELETE FROM user where email= :email";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':email',$email);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

 ?>