package tn.Dari.ProjetSpring.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.Dari.ProjetSpring.Services.AbonnementService;
import tn.Dari.ProjetSpring.Services.IAbonnementService;
import tn.Dari.ProjetSpring.entities.Abonnement;

@RestController
@EnableAutoConfiguration
@RequestMapping(value="/Abonnement")
public class AbonnementRestController implements IAbonnementService {

	@Autowired
	AbonnementService ab;
	
	@Override
	@PostMapping("/addabonnement")
	public Abonnement addAbonnement(@RequestBody Abonnement abonnement) {
		// TODO Auto-generated method stub
		return ab.addAbonnement(abonnement);
	}

	@Override
	@DeleteMapping("/deleteabonnement/{id}")
	public void deleteAbonnement(@PathVariable("id") Long id) {
		// TODO Auto-generated method stub
		ab.deleteAbonnement(id);
	}

	@Override
	@GetMapping("/showabonnements")
	public List<Abonnement> showAbonnement() {
		// TODO Auto-generated method stub
		return ab.showAbonnement();
	}

	@Override
	@GetMapping("/showabonnement")
	public Optional<Abonnement> showAbonnementbyid() {
		// TODO Auto-generated method stub
		return ab.showAbonnementbyid();
	}

}
