package tn.Dari.ProjetSpring.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.Dari.ProjetSpring.entities.Mortgage;
@Repository
public interface MortgageRepository extends JpaRepository<Mortgage,Long>{

}
