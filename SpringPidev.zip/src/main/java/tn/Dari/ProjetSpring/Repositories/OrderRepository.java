package tn.Dari.ProjetSpring.Repositories;



import org.springframework.data.jpa.repository.JpaRepository;

import tn.Dari.ProjetSpring.entities.Orders;



public interface OrderRepository extends JpaRepository<Orders, Integer> {
	

}
