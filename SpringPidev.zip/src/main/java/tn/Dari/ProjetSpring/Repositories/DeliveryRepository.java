package tn.Dari.ProjetSpring.Repositories;



import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import tn.Dari.ProjetSpring.entities.Delivery;
import tn.Dari.ProjetSpring.entities.DeliveryMan;


public interface DeliveryRepository extends JpaRepository<Delivery, Integer>{
	
	//@Query("SELECT COUNT(d) FROM Delivery d WHERE d.deliverymaniddeliveryman=iddm")
	//public int nbr(int iddm) ;
	//@Modifying
	//@Query("UPDATE Delivery d set d.delivery_man_iddeliveryman")
//	@Query("SELECT delivery_man_iddeliveryman id FROM Delivery d WHERE d.idclientdelivery=id")
//	public long findByidclientd(@Param(value = "id") long id);
	@Query("SELECT d FROM Delivery d WHERE d.dateDelivery <= :date")
	public List<Delivery> findByDatefinlist(@Param(value = "date") Date date);
}

