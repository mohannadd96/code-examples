package tn.Dari.ProjetSpring.Repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tn.Dari.ProjetSpring.entities.*;
@Repository
public interface AssuranceRepository extends JpaRepository<Asssurance,Long> {
	@Query("SELECT a FROM Asssurance a WHERE CONCAT (a.nameAssurance ,a.typeAssurance, a.adressAssurance ) LIKE %:nameassurance% ")
	public List<Asssurance> findByNameAssurance(@Param(value = "nameassurance") String nameAssurance);
}
