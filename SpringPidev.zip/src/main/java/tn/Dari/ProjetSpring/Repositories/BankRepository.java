package tn.Dari.ProjetSpring.Repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import tn.Dari.ProjetSpring.entities.Bank;

public interface BankRepository extends CrudRepository<Bank,Long>{
	@Query("SELECT b FROM Bank b WHERE b.datePrevu = :date ")
	public Bank findByDatefin(@Param(value = "date") Date date);

	@Query("SELECT b FROM Bank b ORDER BY b.marge ASC ")
	public List<Bank> findByTri();
	
	@Query("SELECT b FROM Bank b WHERE b.datePrevu <= :date")
	public List<Bank> findByDatefinlist(@Param(value = "date") Date date);
}
