package tn.Dari.ProjetSpring.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tn.Dari.ProjetSpring.entities.Cart;
@Repository("CartRepo")
public interface CartRepository  extends JpaRepository<Cart, Long> {
	

	@Query(value ="SELECT SUM(p.priceProduct) FROM product p  INNER JOIN  Cart c  WHERE c.user_iduser =:idUser AND c.product_idproduct=p.idProduct",nativeQuery = true)
	int  SUMCART(@Param(value = "idUser") Long idUser);
@Query("SELECT m FROM cart m WHERE m.User.idUser=:id")
List<Cart> UserItem(@Param(value="id")Long id);
@Modifying
@Query("DELETE FROM cart c WHERE c.User.idUser=:id")

void supprimerCart(@Param(value="id")long id);
@Modifying
@Query("DELETE FROM cart c WHERE c.Product.idProduct=:id")
void supprimerProductFromCart(@Param(value="id")long id);

}
