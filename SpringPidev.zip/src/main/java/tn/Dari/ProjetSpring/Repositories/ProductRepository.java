package tn.Dari.ProjetSpring.Repositories;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tn.Dari.ProjetSpring.entities.Cart;
import tn.Dari.ProjetSpring.entities.Product;
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	@Query("SELECT p FROM Product p WHERE p.nameProduct LIKE %:nameProduct% OR p.imageProduct LIKE %:nameProduct% OR p.descriptionProduct LIKE %:nameProduct%")
	public List<Product> findByNameAssurance(@Param(value = "nameProduct") String nameProduct);

	@Query("SELECT m FROM Product m WHERE m.User.idUser=:id")
	List<Product> ListProductByUser(@Param(value="id")Long id);
}
