package tn.Dari.ProjetSpring.Repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tn.Dari.ProjetSpring.entities.Delivery;
import tn.Dari.ProjetSpring.entities.DeliveryManNote;

@Repository
public interface DeliveryManNoteRepository extends JpaRepository<DeliveryManNote, Integer> {

	@Query("SELECT idDeliveryMan FROM DeliveryMan d WHERE d.rateDeliveryMan <= :note")
	public List<Integer> lownote(@Param(value = "note") float note);
	
	@Query("SELECT idDeliveryMan FROM DeliveryMan d WHERE d.etatDeliveryMan = false")
	public List<Integer> lownotes();
	
	//@Query("SELECT idDeliveryManNote FROM DeliveryManNote d WHERE d.deliveryManNote <= :note")
	//public List<Integer> notes(@Param(value = "note") int note);
}
