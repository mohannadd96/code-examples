package tn.Dari.ProjetSpring.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.Wishlist;
@Repository

public interface WishlistRepository extends JpaRepository<Wishlist, Long> {
	@Query("SELECT p FROM Wishlist w INNER JOIN w.Product p WHERE w.User.idUser=?1")
	List<Product> WishlistClient(Long idUser);
	@Modifying
	@Query("DELETE FROM Wishlist w WHERE w.User.idUser=:User AND w.Product.idProduct=:id")
	void supprimerWhislistByUserAndProduct(@Param(value="id")long id,@Param(value="User")long idUser);


}
