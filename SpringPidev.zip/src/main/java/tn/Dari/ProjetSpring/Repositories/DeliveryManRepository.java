package tn.Dari.ProjetSpring.Repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tn.Dari.ProjetSpring.entities.DeliveryMan;
@Repository
public interface DeliveryManRepository extends JpaRepository<DeliveryMan, Integer> {

	@Query("SELECT d FROM DeliveryMan d WHERE d.telDeliveryMan LIKE %:teldeliveryman%  OR d.nameDeliveryMan LIKE %:teldeliveryman% OR d.cityDeliveryMan LIKE %:teldeliveryman%")
	public List<DeliveryMan> findByTelDeliveryMan(@Param(value = "teldeliveryman") String Tel);
	
	@Query("SELECT d FROM DeliveryMan d WHERE d.etatDeliveryMan=0 ")
	public List<DeliveryMan> findByDeliveryManbaned();
	
	@Query("SELECT idDeliveryMan FROM DeliveryMan d")
	public List<Integer> iddm();
	
	//@Modifying
	//@Query(value = "UPDATE DeliveryMan b INNER JOIN DeliveryManNote d ON d.idDeliveryManNote=b.idDeliveryMan SET b.rateDeliveryMan=(SELECT AVG(deliveryManNote) FROM DeliveryManNote ) WHERE d.idDeliveryManNote=b.idDeliveryMan",nativeQuery = true)
	//public int insertRate();
	@Query("SELECT AVG(deliveryManNote) FROM DeliveryManNote d WHERE d.idDeliveryManNote=:id")
	public Float insertRate(@Param(value = "id") long id);
	
	@Query("UPDATE DeliveryMan d SET d.etatDeliveryMan=false where d.idDeliveryMan=:id")
	public void disabledm(@Param(value = "id") int id);
	
}
