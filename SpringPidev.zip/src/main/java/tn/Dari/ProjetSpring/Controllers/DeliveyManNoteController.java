package tn.Dari.ProjetSpring.Controllers;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.Dari.ProjetSpring.Repositories.DeliveryManNoteRepository;
import tn.Dari.ProjetSpring.Repositories.DeliveryManRepository;
import tn.Dari.ProjetSpring.Repositories.DeliveryRepository;
import tn.Dari.ProjetSpring.Services.DeliveryManNoteService;
import tn.Dari.ProjetSpring.Services.DeliveryManService;
import tn.Dari.ProjetSpring.Services.DeliveryService;
import tn.Dari.ProjetSpring.entities.Delivery;
import tn.Dari.ProjetSpring.entities.DeliveryMan;
import tn.Dari.ProjetSpring.entities.DeliveryManNote;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.mail.MessagingException;
import javax.servlet.ServletOutputStream;

@RestController

@Transactional
@EnableAutoConfiguration
@RequestMapping(value ="/deliverymannote")
public class DeliveyManNoteController {

	@Autowired
	DeliveryManService DeliveryManService;
	@Autowired
	DeliveryManRepository dmr;
	@Autowired
	DeliveryManNoteRepository dmnr;
	@Autowired
	DeliveryManNoteService DeliveryManNoteService;
	@Autowired
	DeliveryRepository DeliveryRepository;
	@Autowired
	DeliveryService ds;
	@Autowired
	HttpSession session;
	@PostMapping("/save")
	public DeliveryManNote save(@RequestBody DeliveryManNote deliverymannote )
	{
		Long id=(Long)session.getAttribute("name");
		deliverymannote.setIdClientDeliveryNote(id);	
		List<Delivery> d = DeliveryRepository.findAll();
		for (Iterator<Delivery> il = d.iterator(); il.hasNext();)
		 {
			Delivery dd= il.next();
			if(id == dd.getIdClientDelivery())
			{
				deliverymannote.setIdDeliveryManNote(dd.getDeliveryMan().getIdDeliveryMan());
				deliverymannote.setIdoDeliveryNote(dd.getIdDelivery());
				//ds.deleteDelivery(dd.getIdDelivery());
			}
				
		 }
		DeliveryManNoteService.saveOrUpdate(deliverymannote);
		
			return deliverymannote;
	 }
	
	@GetMapping ("/notification")
	public void notification() throws MessagingException

	{
		  DeliveryManNoteService.notification();
		  
	}
	
	 @GetMapping("/excel")
	    public void exportToExcel(HttpServletResponse response) throws IOException {
	        response.setContentType("application/octet-stream");
	        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
	        String currentDateTime = dateFormatter.format(new Date());
	         
	        String headerKey = "Content-Disposition";
	        //String headerValue = "attachment; filename=users_" + currentDateTime + ".xlsx";
	        String headerValue = "attachment; filename=DisabledDM_.xlsx";
	        response.setHeader(headerKey, headerValue);
	         
	        List<DeliveryMan> list = dmr.findByDeliveryManbaned();
	         
	      // Deliverymanbaned excelExporter = new Deliverymanbaned(list);
	       // DeliveryManNoteService.Deliverymanbaned(list);
	       // DeliveryManNoteService excelExporter = new DeliveryManNoteService.Deliverymanbaned(list);
	        DeliveryManNoteService excelExporter = new DeliveryManNoteService(list);
	         
	        excelExporter.export(response);    
	    }  
}
