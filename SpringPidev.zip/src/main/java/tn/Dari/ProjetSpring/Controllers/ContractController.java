package tn.Dari.ProjetSpring.Controllers;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.DocumentException;

import tn.Dari.ProjetSpring.Repositories.ContractRepository;
import tn.Dari.ProjetSpring.Services.ContractService;
import tn.Dari.ProjetSpring.entities.Contract;

@RestController
@EnableAutoConfiguration
@RequestMapping(value ="/Contract/")
public class ContractController {

	@Autowired
	ContractService cs;
	@Autowired
	ContractRepository cr;
	@PostMapping("Add/{idAssurance}")
	public Contract addContract (@Valid @RequestBody Contract c,@PathVariable (value ="idAssurance") Long idAssurance)
	{
		return cs.addContract(c, idAssurance);
	}
	@GetMapping("List")
	public List<Contract> getAllContract() {
	return cs.getAllContract();
	}

	@GetMapping("/pricesup/{priceContract}")
	public List<Contract> pricesup(@PathVariable float priceContract)
	{	
			return (List<Contract>) cr.priceup(priceContract);
		}
	@GetMapping("/pdf/{idContract}")
	public ResponseEntity<?> generatepdf(@PathVariable Long idContract) throws IOException, URISyntaxException, DocumentException
	{	
			return cs.generateContract(idContract);
		}
}

