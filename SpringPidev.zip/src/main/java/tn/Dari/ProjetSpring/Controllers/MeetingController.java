package tn.Dari.ProjetSpring.Controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.Dari.ProjetSpring.Services.MeetingService;
import tn.Dari.ProjetSpring.entities.Meeting;
import tn.Dari.ProjetSpring.entities.Post;

@RestController
@EnableAutoConfiguration
@RequestMapping(value ="/Meeting")
public class MeetingController {

	@Autowired
	MeetingService me;
	@Autowired
	HttpSession session;
	@PostMapping("Add/{idPost}")
	public Meeting addMeeting (/*@Valid*/ @RequestBody Meeting M,@PathVariable int idPost)
	{
		return me.addMeeting(M,idPost);
	}
	
	@PutMapping("Update/{idMeeting}")
	public Meeting updateMeeting(@PathVariable Long idMeeting,/*@Valid*/ @RequestBody Meeting meeting)
	{
		return me.updateMeeting(idMeeting, meeting);
	}
	@DeleteMapping("Delete/{idMeeting}")
	public ResponseEntity<?> deleteAssurance(@PathVariable Long idMeeting)
	{
		return me.deleteMeeting(idMeeting);
		
	}
	@GetMapping("List")
	public List<Meeting> getAllMeeting() {
	return me.getAllMeeting();
	}
	@GetMapping("MeetingUser")
	public List<Meeting> MeetingUser() {
		Long id=(Long)session.getAttribute("name");	 
	return me.MeetingUser(id);
	}
	
	@GetMapping("afficherpostsell")
	public List<Post> afficherpostsell() {
	return me.afficherpostsell();
	}
	@GetMapping("afficherpostrent")
	public List<Post> afficherpostrent() {
	return me.afficherpostrent();
	}
	@GetMapping("/SMSList")
	public List<Meeting> SMSMeeting() {
	return me.SMSMeeting();
	}
}
