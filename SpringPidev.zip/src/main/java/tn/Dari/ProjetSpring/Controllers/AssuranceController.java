package tn.Dari.ProjetSpring.Controllers;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import tn.Dari.ProjetSpring.Repositories.AssuranceRepository;
import tn.Dari.ProjetSpring.Services.AssuranceService;
import tn.Dari.ProjetSpring.entities.Asssurance;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.validation.Valid;
import org.springframework.lang.Nullable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@RestController
@EnableAutoConfiguration
@RequestMapping(value ="/Assurance/")
public class AssuranceController {

	@Autowired
	AssuranceService as;
	@Autowired
	AssuranceRepository ar;
	@PostMapping("Add")
	public Asssurance addAssurance (@Valid @RequestBody Asssurance A)
	{
		return as.addAssurance(A);
	}
	
	@PutMapping("Update/{idAssurance}")
	public Asssurance updateAssurance(@PathVariable Long idAssurance,@Valid @RequestBody Asssurance assurance)
	{
		return as.updateAssurance(idAssurance, assurance);
	}
	@DeleteMapping("Delete/{idAssurance}")
	public ResponseEntity<?> deleteAssurance(@PathVariable Long idAssurance)
	{
		return as.deleteAssurance(idAssurance);
		
	}
	@GetMapping("List")
	public List<Asssurance> getAllAssurance() {
	return as.getAllAssurance();
	}
	
	@GetMapping("Search/{nameAssurance}")
	public List<Asssurance> getByNameAssurance(@PathVariable String nameAssurance) {
	return as.findByName(nameAssurance);
	}
	@PostMapping("/file")
    @ResponseBody
    public Asssurance  uploddimg (@RequestParam("file") @Nullable MultipartFile file , @RequestParam("idAssurance") Long idAssurance ) {
        Asssurance a =ar.findById(idAssurance).get();
        if(file==null) {
            a.setPictureAssurance("C:\\xampp\\image_app\\defaultPic.png");
            ar.save(a);
        }else {
            try { 
                File f = new File("C:\\xampp\\image_app\\"+ idAssurance+file.getOriginalFilename());
                file.transferTo(f);
                a.setPictureAssurance("assurance"+idAssurance+file.getOriginalFilename());
                ar.save(a);
            } catch (IllegalStateException e) {
             e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return(a);
    }
	
}
