package tn.Dari.ProjetSpring.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.Dari.ProjetSpring.Repositories.DeliveryManRepository;
import tn.Dari.ProjetSpring.Services.DeliveryManService;
import tn.Dari.ProjetSpring.entities.DeliveryMan;

@RestController

@Transactional
@EnableAutoConfiguration
@RequestMapping(value ="/deliveryman")
public class DeliveryManController {
	@Autowired
	DeliveryManService DeliveryManService;
	@Autowired
	DeliveryManRepository dmr;
	@PostMapping("/save")
	public DeliveryMan save(@RequestBody DeliveryMan deliveryman)
	{
		DeliveryManService.saveOrUpdate(deliveryman);
			return deliveryman;
	 }
	@GetMapping("/list")
	public List<DeliveryMan> listDeliveryMan(){
			
		
			
			return DeliveryManService.getAllDeliveryMan();
		}
	
	@GetMapping("/recherche/{telDeliveryMan}")
	public List<DeliveryMan> findByTelDeliveryMan(@PathVariable String telDeliveryMan)
	{	
			return (List<DeliveryMan>)dmr.findByTelDeliveryMan(telDeliveryMan);
		}
	@GetMapping ("/list/{id}")
	public DeliveryMan GetbyId(@PathVariable int id)

	{
		
		return DeliveryManService.getByid(id);
	}

	@DeleteMapping("/delete/{id}")
	public  String deleteDeliveryMan(@PathVariable(value = "id")int id){
		
		DeliveryManService.deleteDeliveryMan(id);
		return "Deleted succesfully id= "+id;
	}

	@PutMapping("/update/{id}")
	public DeliveryMan updateDeliveryMan(@PathVariable (value = "id")int id,@RequestBody DeliveryMan deliveryman)
	{
		
		return DeliveryManService.updateDeliveryMan(id, deliveryman);
	}
	
	@PutMapping("/rate")
	public void rate()
	{
		
		DeliveryManService.rate();
	}
}
