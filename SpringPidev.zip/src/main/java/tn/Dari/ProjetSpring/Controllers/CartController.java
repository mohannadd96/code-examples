package tn.Dari.ProjetSpring.Controllers;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.stripe.exception.StripeException;

import com.stripe.model.checkout.Session;
import tn.Dari.ProjetSpring.Repositories.ProductRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.Services.CartService;
import tn.Dari.ProjetSpring.Services.OrderService;
import tn.Dari.ProjetSpring.entities.ApiResponse;
import tn.Dari.ProjetSpring.entities.Cart;

import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.StripeResponse;
import tn.Dari.ProjetSpring.entities.User;



@RestController
@Transactional
@EnableAutoConfiguration
@RequestMapping(value = "/cart")
public class CartController {
	@Autowired
	CartService ServiceCart;
	@Autowired
	 ProductRepository pr;
	@Autowired
	UserRepository userep;
	@Autowired
	OrderService ServiceOrder;
	@Autowired
	HttpSession session;
	
	
	@PostMapping("/save/{idproduct}")
	public Cart addCart ( @RequestBody Cart cart,@PathVariable (value ="idproduct") Long idproduct)
	{
		Long iduser = (Long) session.getAttribute("name");
		return ServiceCart.saveCart(cart, idproduct,iduser);
	}
		
	
	
	@GetMapping("/list")
public List<Cart> listCart(){
		
		
		
		return ServiceCart.getAllCart();
	}

	
	@GetMapping("/SUM")
	public int SUMPRODUIT(){
		Long iduser = (Long) session.getAttribute("name");
		return ServiceCart.SUMPRODUIT(iduser);
	}
	@GetMapping ("/list/{id}")
	public Cart GetbyId(@PathVariable int id)
	
	{
		
		return ServiceCart.getByid(id);
	}
	@GetMapping ("/listUser")
	public List<Cart> GetbyId()
	
	{
		Long iduser = (Long) session.getAttribute("name");
		return ServiceCart.getByUser(iduser);
	}
	@DeleteMapping("/deleteAllProduct")
	public  String deleteProduct(){
		
		Long id = (Long) session.getAttribute("name");
		ServiceCart.SupprimerallCart(id);
		
		return "Deleted succesfully id= "+id;
	}
	
	@DeleteMapping("/deleteProduct/{id}")
	public  String deleteProductFromCart(@PathVariable(value = "id")long id){
		
		ServiceCart.SupprimerProductFromCart(id);
		
		return "Deleted succesfully id= "+id;
	}
	  @PostMapping("/create-checkout-session")
	    public ResponseEntity<StripeResponse> checkoutList() throws StripeException {
		 
		  Long id = (Long) session.getAttribute("name");
	        Session session = ServiceOrder.createSession(id);
	        StripeResponse stripeResponse = new StripeResponse(session.getId());
	        return new ResponseEntity<StripeResponse>(stripeResponse,HttpStatus.OK);
	    }
	  
	  @PostMapping("/add/{sessionid}")
	    public ResponseEntity<ApiResponse> placeOrder(@PathVariable(value = "sessionid")String sessionid) 
	    {
	    // authenticationService.authenticate(token);
	      //  int userId = authenticationService.getUser(token).getId();
	        //orderService.placeOrder(userId, sessionId);
		  Long id = (Long) session.getAttribute("name");
		  User user =  userep.findById(id).get();
		  ServiceOrder.placeOrder(user, sessionid);
	        return new ResponseEntity<ApiResponse>(new ApiResponse(true, "Order has been placed"), HttpStatus.CREATED);
	
}
}
