package tn.Dari.ProjetSpring.Controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.Dari.ProjetSpring.Services.MortgageService;
import tn.Dari.ProjetSpring.entities.Mortgage;

@RestController
@EnableAutoConfiguration
@RequestMapping(value ="/Mortgage/")
public class MortgageController {
	@Autowired
	MortgageService ms;
	@PostMapping("find/{idBank}/{idPost}")
	public ResponseEntity<?> simulationcredit (@Valid @RequestBody Mortgage mortgage,@PathVariable Long idBank,@PathVariable int idPost)
	{
		return ms.compare(mortgage, idPost, idBank);
	}
	
}
