package tn.Dari.ProjetSpring.Controllers;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.beust.jcommander.internal.Nullable;
import com.google.zxing.WriterException;

import tn.Dari.ProjetSpring.Repositories.ProductRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.Services.ProductService;
import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.User;

@RestController
@EnableAutoConfiguration
@Transactional

@RequestMapping(value = "/product")
public class ProductController {
	
	
	private static final String QR_CODE_IMAGE_PATH = "src/main/resources/QRCode" ;

	@Autowired
	ProductService ServiceProduct;
	@Autowired
	ProductRepository pr;
	@Autowired
	UserRepository user;
	@Autowired
	HttpSession session;

	@PostMapping("/save")
	@ResponseBody
	public void save(@RequestBody Product product) throws WriterException, IOException  {


		  Calendar currentDate = Calendar.getInstance();
		  Date d =currentDate.getTime();

		// for (int i = 0; i <ServiceProduct.getAllProducts().size(); i++){
		// String name= pr.getClass().getName();
		// long id=product.getUser().getIdUser();
		String nom = product.getNameProduct();
		 product.setDateProduct(d);
		User user1;
		Long id = (Long) session.getAttribute("name");
		user1 = user.findById(id).get();
		product.setUser(user1);
		ServiceProduct.saveOrUpdate(product);

		QRCodeGenerator.generateQRCodeImage(nom, QR_CODE_IMAGE_PATH + product.getIdProduct() + ".png");

	}

	@GetMapping("/list")
	public List<Product> listProduct() {

		return ServiceProduct.getAllProducts();
	}

	@GetMapping("/listProductByUser")
	public List<Product> GetbyId()

	{
		Long id = (Long) session.getAttribute("name");
		return ServiceProduct.getByid(id);
	}

	@DeleteMapping("/delete/{id}")
	public String deleteProduct(@PathVariable(value = "id") Long id) {
		Long idUser = (Long) session.getAttribute("name");

		ServiceProduct.deleteProduct(id,idUser);
		return "Deleted succesfully id= " + id;
	}

	@PutMapping("/update/{id}")
	public Product updateProduct(@PathVariable(value = "id") Long id,@RequestBody Product Product) {
		Long idUser = (Long) session.getAttribute("name");
		return ServiceProduct.updateProduct(id, idUser, Product);
	}

	@PostMapping("/file")

	public Product uploddImage(@RequestParam("file") @Nullable MultipartFile file,@RequestParam("idprod") Long idprod) {
		Product product = pr.findById(idprod).get();
		if (file == null) {
			product.setImageProduct("defaultPic.jpg");
			pr.save(product);
		} else {
			try {
				File f = new File("C:\\xampp\\image_app\\" + file.getOriginalFilename());
				file.transferTo(f);
				product.setImageProduct(file.getOriginalFilename());
				pr.save(product);
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return (product);
	}

}
