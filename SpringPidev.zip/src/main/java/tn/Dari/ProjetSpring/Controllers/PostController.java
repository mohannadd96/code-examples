package tn.Dari.ProjetSpring.Controllers;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.lang.Nullable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import tn.Dari.ProjetSpring.Repositories.PostRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.Services.PostService;
import tn.Dari.ProjetSpring.entities.Asssurance;
import tn.Dari.ProjetSpring.entities.DeliveryMan;
import tn.Dari.ProjetSpring.entities.Post;
import tn.Dari.ProjetSpring.entities.User;

@RestController
@Transactional
@EnableAutoConfiguration
@RequestMapping(value ="/post")

public class PostController {
@Autowired
PostService PostService;
@Autowired
PostRepository pr;
@Autowired
UserRepository ur;
@Autowired
HttpSession session;
@PostMapping("/save")
public Post save(@RequestBody Post post)
{		Long id=(Long)session.getAttribute("name");	 
		User u = ur.findById(id).get();
	   post.setUser(u);
	   PostService.saveOrUpdate(post);
		return post;
 }
@GetMapping("/list")
public List<Post> listPost(){
		
	
		
		return PostService.getAllPost();
	}
@GetMapping ("/list/{id}")
public Post GetbyId(@PathVariable int id)

{
	
	return PostService.getByid(id);
}

@DeleteMapping("/delete/{id}")
public  String deletePost(@PathVariable(value = "id")int id){
	
	PostService.deletePost(id);
	return "Deleted succesfully id= "+id;
}

@PutMapping("/update/{id}")
public Post updatePost(@PathVariable (value = "id")int id,@RequestBody Post Post)
{
	
	return PostService.updatePost(id, Post);
}

@GetMapping("/pricesup/{pricePost}")
public List<Post> pricesup(@PathVariable float pricePost)
{	
		return (List<Post>)pr.pricesup(pricePost);
	}

@GetMapping("/priceinf/{pricePost}")
public List<Post> priceinf(@PathVariable float pricePost)
{	
		return (List<Post>)pr.priceinf(pricePost);
	}

@GetMapping("/rent")
public List<Post> rent()
{	
		return (List<Post>)pr.rent();
	}

@GetMapping("/sell")
public List<Post> sell()
{	
		return (List<Post>)pr.sell();
	}

@PostMapping("/file")
@ResponseBody
public Post  uploddimg (@RequestParam("file") @Nullable MultipartFile file , @RequestParam("idPost") int idPost ) {
    Post p =pr.findById(idPost).get();
    if(file==null) {
        p.setImagePost("C:\\xampp\\image_app\\defaultPic.png");
        pr.save(p);
    }else {
        try { 
            File f = new File("C:\\xampp\\image_app\\"+ idPost+file.getOriginalFilename());
            file.transferTo(f);
            p.setImagePost("assurance"+idPost+file.getOriginalFilename());
            pr.save(p);
        } catch (IllegalStateException e) {
         e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    return(p);
}
}
