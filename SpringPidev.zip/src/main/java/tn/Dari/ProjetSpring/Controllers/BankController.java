package tn.Dari.ProjetSpring.Controllers;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import tn.Dari.ProjetSpring.Repositories.BankRepository;
import tn.Dari.ProjetSpring.Services.BankService;
import tn.Dari.ProjetSpring.entities.Asssurance;
import tn.Dari.ProjetSpring.entities.Bank;
@RestController
@EnableAutoConfiguration
@RequestMapping(value ="/Bank/")
public class BankController {
	@Autowired
	BankService bs;
	@Autowired
	BankRepository br;
	
	@PostMapping("Add")
	public Bank addAssurance (@Valid @RequestBody Bank bank)
	{
		
		return bs.addBank(bank);
	}
	
	@PutMapping("Update/{idBank}")
	public Bank updateBank(@PathVariable Long idBank,@Valid @RequestBody Bank bank)
	{
		return bs.updateBank(idBank, bank);
	}
	@DeleteMapping("Delete/{idBank}")
	public ResponseEntity<?> deleteBank(@PathVariable Long idBank)
	{
		return bs.deleteBank(idBank);
		
	}
	@GetMapping("List")
	public List<Bank> getAllBanks() {
	return bs.getAllBank();
	}
	@GetMapping("check")
	public Bank checkBanks() {
	return bs.check();
	}
	@GetMapping("Tri")
	public List<Bank> getTri() {
	return  br.findByTri();
	}
	@GetMapping("disable")
	public List<Bank> disableBanks() {
	return bs.disable();
	}
	@GetMapping("enable/{idBank}")
	public ResponseEntity<?> enableBanks(@PathVariable Long idBank) {
	return bs.enable(idBank);
	}
	@PostMapping("/file")
    @ResponseBody
    public Bank  uploddimg (@RequestParam("file") @Nullable MultipartFile file , @RequestParam("idBank") Long idBank ) {
		Bank b =br.findById(idBank).get();
        if(file==null) {
            b.setPictureBank("C:\\xampp\\image_app\\defaultPic.png");
            br.save(b);
        }else {
            try { 
                File f = new File("C:\\xampp\\image_app\\"+ idBank+file.getOriginalFilename());
                file.transferTo(f);
                b.setPictureBank("Bnak"+idBank+file.getOriginalFilename());
                br.save(b);
            } catch (IllegalStateException e) {
             e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return(b);
    }
}
