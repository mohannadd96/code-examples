package tn.Dari.ProjetSpring.Controllers;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.context.ApplicationContext;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.Dari.ProjetSpring.Services.DeliveryManService;
import tn.Dari.ProjetSpring.Services.DeliveryService;
import tn.Dari.ProjetSpring.entities.Delivery;
import tn.Dari.ProjetSpring.entities.DeliveryMan;

@RestController
@Transactional
@EnableAutoConfiguration
@RequestMapping(value ="/delivery")
public class DeliveryController {
	@Autowired
	DeliveryService DeliveryService;
	
	@Autowired
    private JavaMailSender emailSender;
	@Autowired
	HttpSession session;
	//public void sendEmail( boolean state) {

      //  SimpleMailMessage msg = new SimpleMailMessage();
       // msg.setTo("mohamed.bensalah@esprit.tn");
       // if(state == true)
       // {
       // msg.setSubject("Delivery service");
       // msg.setText("Hello, please fill this form. "
        //		+ 
        	//	"Click here : https://docs.google.com/forms/d/1Iw9uYoVqkfn-6AR3Zv09oIJPV8Ho4e8eYPyYropiCQk/edit"
        		//+ " \n Best Regards!");
  //      }
        
      //  emailSender.send(msg);

    //}
	
	
	@PostMapping("/save")
	public Delivery save(@RequestBody Delivery delivery)
	{
		//sendEmail(true);
		Long id=(Long)session.getAttribute("name");	 
		delivery.setIdClientDelivery(id);
		DeliveryService.saveOrUpdate(delivery);
			return delivery;
	 }
	@PutMapping ("/affect/{idDelivety}/{idDeliveryMan}")
	public void affect(@PathVariable int idDelivety,@PathVariable int idDeliveryMan)

	{
		
		 DeliveryService.affect(idDelivety, idDeliveryMan);
	}
	
	@PutMapping ("/affect2")
	public void affect2()

	{
		 
		 DeliveryService.affect2();
	}
	
	@GetMapping("/list")
	public List<Delivery> listDelivery(){
			
		
			
			return DeliveryService.getAllDelivery();
		}
	@GetMapping ("/list/{id}")
	public Delivery GetbyId(@PathVariable int id)

	{
		
		return DeliveryService.getByid(id);
	}
	
	@GetMapping ("/notification")
	public void notification()

	{
		  DeliveryService.notification();
	}

	@DeleteMapping("/delete/{id}")
	public  String deleteDelivery(@PathVariable(value = "id")int id){
		
		DeliveryService.deleteDelivery(id);
		return "Deleted succesfully id= "+id;
	}

	@PutMapping("/update/{id}")
	public Delivery updateDelivery(@PathVariable (value = "id")int id,@RequestBody Delivery delivery)
	{
		
		return DeliveryService.updateDelivery(id, delivery);
	}
	
	@PutMapping("/check/{id}")
	public void checkDelivery(@PathVariable int id)
	{
		
		DeliveryService.checkDelivery(id);
	}
	
}
