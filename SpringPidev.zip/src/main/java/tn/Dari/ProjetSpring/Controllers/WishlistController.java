package tn.Dari.ProjetSpring.Controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.Dari.ProjetSpring.Repositories.ProductRepository;
import tn.Dari.ProjetSpring.Services.CartService;
import tn.Dari.ProjetSpring.Services.WishlistService;
import tn.Dari.ProjetSpring.entities.Cart;
import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.Wishlist;

@RestController
@Transactional
@EnableAutoConfiguration
@RequestMapping(value = "/wishlist")
public class WishlistController {
	@Autowired
	WishlistService Servicewishlist;
	@Autowired
	 ProductRepository pr;
	@Autowired
	HttpSession session;
	
	@PostMapping("/save/{idproduct}")
	public Wishlist addwishlist ( @RequestBody Wishlist wishlist,@PathVariable (value ="idproduct") Long idproduct)
	{
		Long iduser = (Long) session.getAttribute("name");
		return Servicewishlist.saveWishlist(wishlist, idproduct ,iduser);
	}
	
	@GetMapping("/list")
public List<Product> listWishlist(){
		
	
		Long iduser = (Long) session.getAttribute("name");
		return  Servicewishlist.ClientWishlist(iduser);
	}	
	
	
	/*
	
	@GetMapping ("/list/{id}")
	public Wishlist GetbyId(@PathVariable Long id)
	
	{
		
		return Servicewishlist.getByid(id);
	}
	*/
	
	@DeleteMapping("/delete/{id}")
	public  String deleteProduct(@PathVariable(value = "id")Long id){
		Long iduser = (Long) session.getAttribute("name");
		return Servicewishlist.deleteWishlist(id,iduser);
		
		
	}


}
