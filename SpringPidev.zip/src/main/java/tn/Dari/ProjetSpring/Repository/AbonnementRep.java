package tn.Dari.ProjetSpring.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import tn.Dari.ProjetSpring.entities.Abonnement;
@Repository
public interface AbonnementRep extends CrudRepository<Abonnement, Long> {

}
