package tn.Dari.ProjetSpring.Security;

import tn.Dari.ProjetSpring.Security.AppAuthProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import tn.Dari.ProjetSpring.Services.UserService;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter  {
	@Autowired
    UserService userDetailsService;

	@Autowired
    private AccessDeniedHandler accessDeniedHandler;
	
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService);
    }
    
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf()
                .disable()
                .exceptionHandling()
                .authenticationEntryPoint(new Http403ForbiddenEntryPoint() {
                })
                .and()
                .authenticationProvider(getProvider())
                .formLogin()
                .loginProcessingUrl("/login")
                .successHandler(new AuthentificationLoginSuccessHandler())
                .failureHandler(new SimpleUrlAuthenticationFailureHandler())
                .and()
                .logout()
                .logoutUrl("/logout")
                .logoutSuccessHandler(new AuthentificationLogoutSuccessHandler())
                .invalidateHttpSession(true)
                .and()
                .authorizeRequests()
                .antMatchers("/login").permitAll()
                .antMatchers("/logout").permitAll()
                .antMatchers("/product/**").permitAll()
                .antMatchers("/wishlist/**").permitAll()
                .antMatchers("/cart/**").permitAll()
                .antMatchers("/post/**").permitAll()
                .antMatchers("/Meeting/**").permitAll()
                .antMatchers("/delivery/**").permitAll()
                .antMatchers("/delivery/affect2").hasAuthority("ADMIN")
                .antMatchers("/delivery/notification").hasAuthority("ADMIN")
                .antMatchers("/deliveryman/**").hasAuthority("ADMIN")
                .antMatchers("/deliverymannote/save").hasAnyAuthority("USER","PREMIUMUSER")
                .antMatchers("/deliverymannote/notification").hasAuthority("ADMIN")
                .antMatchers("/deliverymannote/excel").permitAll()
                .antMatchers("/User/**").hasAnyAuthority("USER","PREMIUMUSER","ADMIN")
                .antMatchers("/Abonnement/showabonnements").hasAuthority("ADMIN")
                .antMatchers("/Abonnement/showabonnement").hasAnyAuthority("USER","PREMIUMUSER")
                .antMatchers("/Abonnement/addabonnement").hasAnyAuthority("USER","PREMIUMUSER")
                .antMatchers("/Abonnement/deleteabonnement").hasAuthority("ADMIN")

                .antMatchers("/Assurance/Add").hasAnyAuthority("ADMIN")
                .antMatchers("/Assurance/file/**").hasAnyAuthority("ADMIN")
                .antMatchers("/Assurance/Update/**").hasAnyAuthority("ADMIN")
                .antMatchers("/Assurance/Delete/**").hasAnyAuthority("ADMIN")
                .antMatchers("/Assurance/List").hasAnyAuthority("PREMIUMUSER")
                .antMatchers("/Assurance/Search/**").hasAnyAuthority("PREMIUMUSER")
                .antMatchers("/Bank/**").hasAnyAuthority("ADMIN")
                .antMatchers("/Mortgage/**").hasAnyAuthority("PREMIUMUSER")
                .antMatchers("/Mortgage/Contract/**").hasAnyAuthority("PREMIUMUSER")
                .anyRequest().permitAll();
    }
    private class AuthentificationLoginSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {
        @Override
        public void onAuthenticationSuccess(HttpServletRequest request,
                                            HttpServletResponse response, Authentication authentication)
                throws IOException, ServletException {
            response.setStatus(HttpServletResponse.SC_OK);
        }
    }
    private class AuthentificationLogoutSuccessHandler extends SimpleUrlLogoutSuccessHandler {
        @Override
        public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response,
                                    Authentication authentication) throws IOException, ServletException {
            response.setStatus(HttpServletResponse.SC_OK);
        }
    }
    @Bean
    public AuthenticationProvider getProvider() {
        AppAuthProvider provider = new AppAuthProvider();
        provider.setUserDetailsService(userDetailsService);
        return provider;
    }
}
