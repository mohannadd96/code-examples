package tn.Dari.ProjetSpring.entities;

import java.util.Set;

//import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="deliverymannote")
public class DeliveryManNote {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="iddeliverynote")
	private long idDeliveryNote;
	
	@Column(name="idclientdeliverynote")
    private long idClientDeliveryNote;
	
	@Column(name="idodeliverynote")
    private long idoDeliveryNote;
	
	@Column(name="iddeliverymannote")
    private long idDeliveryManNote;
	
	@Column(name="deliverymannote")
    private int deliveryManNote;

	public DeliveryManNote() {
		super();
	}

	public DeliveryManNote(long idDeliveryNote, long idClientDeliveryNote, int deliveryManNote) {
		super();
		this.idDeliveryNote = idDeliveryNote;
		this.idClientDeliveryNote = idClientDeliveryNote;
		this.deliveryManNote = deliveryManNote;
	}
	
	

	public DeliveryManNote(long idDeliveryNote, long idClientDeliveryNote, long idoDeliveryNote, long idDeliveryManNote,
			int deliveryManNote) {
		super();
		this.idDeliveryNote = idDeliveryNote;
		this.idClientDeliveryNote = idClientDeliveryNote;
		this.idoDeliveryNote = idoDeliveryNote;
		this.idDeliveryManNote = idDeliveryManNote;
		this.deliveryManNote = deliveryManNote;
	}

	public long getIdDeliveryNote() {
		return idDeliveryNote;
	}

	public void setIdDeliveryNote(long idDeliveryNote) {
		this.idDeliveryNote = idDeliveryNote;
	}

	public long getIdClientDeliveryNote() {
		return idClientDeliveryNote;
	}

	public void setIdClientDeliveryNote(long idClientDeliveryNote) {
		this.idClientDeliveryNote = idClientDeliveryNote;
	}

	public int getDeliveryManNote() {
		return deliveryManNote;
	}

	public void setDeliveryManNote(int deliveryManNote) {
		this.deliveryManNote = deliveryManNote;
	}

	public long getIdDeliveryManNote() {
		return idDeliveryManNote;
	}

	public void setIdDeliveryManNote(long idDeliveryManNote) {
		this.idDeliveryManNote = idDeliveryManNote;
	}

	public long getIdoDeliveryNote() {
		return idoDeliveryNote;
	}

	public void setIdoDeliveryNote(long idoDeliveryNote) {
		this.idoDeliveryNote = idoDeliveryNote;
	}
	
	
}
