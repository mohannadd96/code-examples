package tn.Dari.ProjetSpring.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "bank")
public class Bank {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idbank")
	private Long idBank;

	@Column(name = "namebank")
	//@NotEmpty(message = "*Please provide a Name bank")
	private String nameBank;
	@Column(name = "adessbank")
	//@NotEmpty(message = "*Please provide an adress of the bank")
	private String adressBank;
	@Column(name = "picturebank")
	//@NotEmpty(message = "*Please provide a picture of the bank")
	private String pictureBank;
	@Column(name = "tmm")
	//@NotEmpty(message = "*Please provide your salary")
	private float TMM;
	@Column(name = "marge")
	//@NotEmpty(message = "*Please provide your marge")
	private float marge;
	@Temporal(TemporalType.DATE)
	@Column(name = "dateinsert")
	private Date dateInsert;
	@Temporal(TemporalType.DATE)
	@Column(name = "dateprevu")
	private Date datePrevu;
	@Column(name="statusbank")
	private int statutsBank;
	@JsonIgnore
	@ManyToOne
	private User user;
	

	@JsonIgnore
	@OneToMany(mappedBy = "bank")
	private List<Mortgage> mortgage;

	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public float getTMM() {
		return TMM;
	}

	public void setTMM(float tMM) {
		TMM = tMM;
	}

	public Date getDateInsert() {
		return dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDatePrevu() {
		return datePrevu;
	}

	public void setDatePrevu(Date datePrevu) {
		this.datePrevu = datePrevu;
	}

	public String getAdressBank() {
		return adressBank;
	}

	public void setAdressBank(String adressBank) {
		this.adressBank = adressBank;
	}

	public String getPictureBank() {
		return pictureBank;
	}

	public void setPictureBank(String pictureBank) {
		this.pictureBank = pictureBank;
	}

	

	public List<Mortgage> getMortgage() {
		return mortgage;
	}

	public void setMortgage(List<Mortgage> mortgage) {
		this.mortgage = mortgage;
	}

	public Long getIdBank() {
		return idBank;
	}

	public void setIdBank(Long idBank) {
		this.idBank = idBank;
	}

	public String getNameBank() {
		return nameBank;
	}

	public void setNameBank(String nameBank) {
		this.nameBank = nameBank;
	}

	public float getMarge() {
		return marge;
	}

	public void setMarge(float marge) {
		this.marge = marge;
	}


	public int getStatutsBank() {
		return statutsBank;
	}

	public void setStatutsBank(int statutsBank) {
		this.statutsBank = statutsBank;
	}

	public Bank(Long idBank, String nameBank, String adressBank, String pictureBank, float tMM, float marge,
			Date dateInsert, Date datePrevu, List<Mortgage> mortgage) {
		super();
		this.idBank = idBank;
		this.nameBank = nameBank;
		this.adressBank = adressBank;
		this.pictureBank = pictureBank;
		TMM = tMM;
		this.marge = marge;
		this.dateInsert = dateInsert;
		this.datePrevu = datePrevu;
		this.mortgage = mortgage;
	}

	public Bank() {
		super();
	}

}
