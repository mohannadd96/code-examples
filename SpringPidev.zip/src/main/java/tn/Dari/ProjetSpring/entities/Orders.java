package tn.Dari.ProjetSpring.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;


@Entity
public class Orders {
	
	

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer idOrder;
	    @Temporal(TemporalType.DATE)
	    @Column(name = "created_date")
	    private Date createdDate;

	    @Column(name = "total_price")
	    private int totalPrice;

	    @Column(name = "session_id")
	    private String sessionId;
	    
	    @JsonManagedReference
	    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true,mappedBy="order",fetch = FetchType.LAZY)
	    private List<Cart> cart;
	    @JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "user_id", referencedColumnName = "iduser")
	    private User user;
	    
	    private String Adresse ; 
	    
	    public Orders() {
	    }

	    public Orders( User user, String sessionId,String Adresse,Date d){
	    	this.user = user;
	        this.createdDate = new Date();
	        
	        this.sessionId = sessionId;
	        this.Adresse = Adresse ;
	        this.createdDate=d;
	    }
	    public Orders( User user, String sessionId,Date d){
	    	this.user = user;
	        this.createdDate = new Date();
	        this.createdDate=d;
	     
	        this.sessionId = sessionId;
	    }
	  

	    
	    
	    public List<Cart> getCart() {
	        return cart;
	    }

	    public void setCart(List<Cart> cart) {
	        this.cart = cart;
	    }

	    public User getUser() {
	        return user;
	    }

	    public void setUser(User user) {
	        this.user = user;
	    }

	    public Integer getIdOrder() {
	        return idOrder;
	    }

	    public void setIdOrder(Integer id) {
	        this.idOrder = id;
	    }


	  

	    public Date getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(Date createdDate) {
			this.createdDate = createdDate;
		}

		public String getSessionId() {
			return sessionId;
		}

		public void setSessionId(String sessionId) {
			this.sessionId = sessionId;
		}

		public int getTotalPrice() {
	        return totalPrice;
	    }

	    public void setTotalPrice(int totalPrice) {
	        this.totalPrice = totalPrice;
	    }

	

		public String getAdresse() {
			return Adresse;
		}

		public void setAdresse(String adresse) {
			Adresse = adresse;
		}
	
		public Orders(int TotalPrice, User userId, String sessionId,Date d,String adresse){
	        
	        this.totalPrice =TotalPrice;
	        this.user=userId;
	        this.sessionId = sessionId;
	        this.createdDate= d;
	       this.Adresse=adresse;
	       
	    }
		   

}
