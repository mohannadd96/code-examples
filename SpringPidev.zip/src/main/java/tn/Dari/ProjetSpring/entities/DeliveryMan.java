package tn.Dari.ProjetSpring.entities;

import java.util.Set;

//import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name="deliveryman")
public class DeliveryMan {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="iddeliveryman")
	private int idDeliveryMan;
	@Column(name="teldeliveryman")
	@Length(min = 8, max = 8)
	private String telDeliveryMan;
	@Column(name="namedeliveryman")
	private String nameDeliveryMan;
	@Column(name="citydeliveryman")
	private String cityDeliveryMan;
	@Column(name="etatdeliveryman")
	private boolean etatDeliveryMan;
	@Column(name="ratedeliveryman")
	private float rateDeliveryMan;
	
	//@ManyToMany(cascade = CascadeType.ALL)
    //@JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	@JsonIgnore
	@OneToMany(cascade = CascadeType.ALL, mappedBy="DeliveryMan")
	private Set<Delivery> Delivery;
	

	public DeliveryMan(@Length(min = 8, max = 8) String telDeliveryMan, String nameDeliveryMan, String cityDeliveryMan,
			Set<tn.Dari.ProjetSpring.entities.Delivery> delivery) {
		super();
		this.telDeliveryMan = telDeliveryMan;
		this.nameDeliveryMan = nameDeliveryMan;
		this.cityDeliveryMan = cityDeliveryMan;
		Delivery = delivery;
	}


	public Set<Delivery> getDelivery() {
		return Delivery;
	}


	public void setDelivery(Set<Delivery> delivery) {
		Delivery = delivery;
	}


	public void setIdDeliveryMan(int idDeliveryMan) {
		this.idDeliveryMan = idDeliveryMan;
	}


	public DeliveryMan() {
		super();
	}
	

	public DeliveryMan(String telDeliveryMan) {
		super();
		this.telDeliveryMan = telDeliveryMan;
	}


	public int getIdDeliveryMan() {
		return idDeliveryMan;
	}


	public String getTelDeliveryMan() {
		return telDeliveryMan;
	}


	public void setTelDeliveryMan(String telDeliveryMan) {
		this.telDeliveryMan = telDeliveryMan;
	}


	public String getNameDeliveryMan() {
		return nameDeliveryMan;
	}


	public void setNameDeliveryMan(String nameDeliveryMan) {
		this.nameDeliveryMan = nameDeliveryMan;
	}


	public String getCityDeliveryMan() {
		return cityDeliveryMan;
	}


	public void setCityDeliveryMan(String cityDeliveryMan) {
		this.cityDeliveryMan = cityDeliveryMan;
	}


	public boolean isEtatDeliveryMan() {
		return etatDeliveryMan;
	}


	public void setEtatDeliveryMan(boolean etatDeliveryMan) {
		this.etatDeliveryMan = etatDeliveryMan;
	}


	public float getRateDeliveryMan() {
		return rateDeliveryMan;
	}


	public void setRateDeliveryMan(float rateDeliveryMan) {
		this.rateDeliveryMan = rateDeliveryMan;
	}


	


	
	

}
