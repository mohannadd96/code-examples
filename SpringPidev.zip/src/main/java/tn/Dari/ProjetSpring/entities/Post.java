package tn.Dari.ProjetSpring.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;



@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class,property = "idPost")

public class Post {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idpost")
	private int idPost;

	@Column(name="pricepost")
	private float pricePost;

	@Temporal(TemporalType.DATE)
	@Column(name="datepost")
	private Date datePost;

	@Enumerated(EnumType.STRING)
	@Column(name="typepost")
	private TypePost typePost;

	@Column(name="imagepost")
	private String imagePost;

	@Column(name="descriptionpost")
	private String descriptionPost;

	@Column(name="buildingtype")
	private String buildingType;

	@Column(name="nbofroomspost")
	private int nbOfRoomsPost;

	@Column(name="addresspost")
	private String addressPost;



	@JsonIgnore
	@OneToMany(mappedBy="post")
	private List<Mortgage> mortgage;

	public List<Mortgage> getMortgage() {
		return mortgage;
	}
	public void setMortgage(List<Mortgage> mortgage) {
		this.mortgage = mortgage;
	}
	public void setIdPost(int idPost) {
		this.idPost = idPost;
	}



	@JsonIgnore
	@OneToMany(cascade=CascadeType.ALL,mappedBy="Post")
	private List<Meeting> Meeting;
	@JsonIgnore
	@ManyToOne
	private User user;



	

	//private boolean etatPost ;


	public Post() {
		super();
	}
	public Post(float pricePost, Date datePost, TypePost typePost, String imagePost, String descriptionPost,
			String buildingType, int nbOfRoomsPost, String addressPost) {
		super();
		this.pricePost = pricePost;
		this.datePost = datePost;
		this.typePost = typePost;
		this.imagePost = imagePost;
		this.descriptionPost = descriptionPost;
		this.buildingType = buildingType;
		this.nbOfRoomsPost = nbOfRoomsPost;
		this.addressPost = addressPost;
	}
	public int getIdPost() {
		return idPost;
	}
	public float getPricePost() {
		return pricePost;
	}
	public void setPricePost(float pricePost) {
		this.pricePost = pricePost;
	}
	public Date getDatePost() {
		return datePost;
	}
	public void setDatePost(Date datePost) {
		this.datePost = datePost;
	}

	public TypePost getTypePost() {
		return typePost;
	}
	public void setTypePost(TypePost typePost) {
		this.typePost = typePost;
	}
	public String getImagePost() {
		return imagePost;
	}
	public void setImagePost(String imagePost) {
		this.imagePost = imagePost;
	}
	public String getDescriptionPost() {
		return descriptionPost;
	}
	public void setDescriptionPost(String descriptionPost) {
		this.descriptionPost = descriptionPost;
	}
	public String getBuildingType() {
		return buildingType;
	}
	public void setBuildingType(String buildingType) {
		this.buildingType = buildingType;
	}
	public int getNbOfRoomsPost() {
		return nbOfRoomsPost;
	}
	public void setNbOfRoomsPost(int nbOfRoomsPost) {
		this.nbOfRoomsPost = nbOfRoomsPost;
	}
	public String getAddressPost() {
		return addressPost;
	}
	public void setAddressPost(String addressPost) {
		this.addressPost = addressPost;
	}
	public List<Meeting> getMeeting() {
		return Meeting;
	}
	public void setMeeting(List<Meeting> meeting) {
		Meeting = meeting;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}



	



}
