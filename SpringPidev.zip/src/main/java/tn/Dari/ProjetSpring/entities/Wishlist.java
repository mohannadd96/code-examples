package tn.Dari.ProjetSpring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name ="wishlist")
public class Wishlist {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="idwishlist")
    long idWishlist;
	@JsonIgnore
	@ManyToOne
	Product Product;
	@JsonIgnore
	@JoinColumn(name="userid")
	@OneToOne
	User User;
	

	public User getUser() {
		return User;
	}

	public void setUser(User user) {
		User = user;
	}

	public long getIdWishlist() {
		return idWishlist;
	}

	public Product getProduct() {
		return Product;
	}

	public void setProduct(Product product) {
		Product = product;
	}

	public void setIdWishlist(long idWishlist) {
		this.idWishlist = idWishlist;
	}

}
