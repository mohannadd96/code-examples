package tn.Dari.ProjetSpring.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "mortgage")
public class Mortgage {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idmortgage")
	private Long idMortgage;

	@Column(name = "namemortgage")
	//@NotEmpty(message = "*Please provide a Mortgage Name")
	private String nameMortgage;

	@Column(name = "salaryuser")
	//@NotEmpty(message = "*Please provide your salary")
	private float salaryMortgage;

	@Column(name = "nbanneemortgage")
	//@NotEmpty(message = "*Please provide your salary")
	private int nbAnneeMortgage;

	

	public int getNbAnneeMortgage() {
		return nbAnneeMortgage;
	}

	public void setNbAnneeMortgage(int nbAnneeMortgage) {
		this.nbAnneeMortgage = nbAnneeMortgage;
	}
	@JsonIgnore
	@ManyToOne
	private User user;
	@JsonIgnore
	@ManyToOne
	private Bank bank;
	@JsonIgnore
	@ManyToOne
	private Post post;

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public Post getPost() {
		return post;
	}

	public void setPost(Post post) {
		this.post = post;
	}

	public Long getIdMortgage() {
		return idMortgage;
	}

	public void setIdMortgage(Long idMortgage) {
		this.idMortgage = idMortgage;
	}

	public String getNameMortgage() {
		return nameMortgage;
	}

	public void setNameMortgage(String nameMortgage) {
		this.nameMortgage = nameMortgage;
	}

	public float getSalaryMortgage() {
		return salaryMortgage;
	}

	public void setSalaryMortgage(float salaryMortgage) {
		this.salaryMortgage = salaryMortgage;
	}
	public Mortgage(Long idMortgage, String nameMortgage,float salaryMortgage,
			int nbAnneeMortgage, Bank bank, Post post) {
		super();
		this.idMortgage = idMortgage;
		this.nameMortgage = nameMortgage;
		this.salaryMortgage = salaryMortgage;
		this.nbAnneeMortgage = nbAnneeMortgage;
		this.bank = bank;
		this.post = post;
	}

	public Mortgage() {
		super();
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	

}
