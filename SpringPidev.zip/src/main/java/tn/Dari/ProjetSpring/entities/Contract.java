package tn.Dari.ProjetSpring.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Contracts")
public class Contract implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idcontract")
	private Long idContract;

	@Column(name = "datestartcontract")
	@Temporal(TemporalType.DATE)
	private Date DateStartContract;

	@Column(name = "dateendcontract")
	@Temporal(TemporalType.DATE)
	private Date DateEndContract;

	@Column(name = "pricecontract")
	//@NotEmpty(message = "*Please provide a price Contract")
	private float priceContract;

	@Column(name = "descriptioncontract")
	@NotEmpty(message = "*Please provide a Description of Contract")
	private String DescriptionContract;
	@JsonIgnore
	@ManyToOne
	private Asssurance assurance;

	public Asssurance getAssurance() {
		return assurance;
	}

	public void setAssurance(Asssurance assurance) {
		this.assurance = assurance;
	}

	public Long getIdContract() {
		return idContract;
	}

	public void setIdContract(Long idContract) {
		this.idContract = idContract;
	}

	public Date getDateStartContract() {
		return DateStartContract;
	}

	public void setDateStartContract(Date dateStartContract) {
		DateStartContract = dateStartContract;
	}

	public Date getDateEndContract() {
		return DateEndContract;
	}

	public void setDateEndContract(Date dateEndContract) {
		DateEndContract = dateEndContract;
	}

	public float getPriceContract() {
		return priceContract;
	}

	public void setPriceContract(float priceContract) {
		this.priceContract = priceContract;
	}

	public String getDescriptionContract() {
		return DescriptionContract;
	}

	public void setDescriptionContract(String descriptionContract) {
		DescriptionContract = descriptionContract;
	}

}
