package tn.Dari.ProjetSpring.entities;


import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity(name="cart")
@Table(name ="cart")
public class Cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="idcart")
	private long idCart;
	@Column(name="prixcart")
	private int prixCart;
	@Temporal(TemporalType.DATE)
	@Column(name="datecommande")
	private Date dateCommande;
	
	public int getQuantityProduitPanier() {
		return QuantityProduitPanier;
	}
	public void setQuantityProduitPanier(int quantityProduitPanier) {
		QuantityProduitPanier = quantityProduitPanier;
	}
	public User getUser() {
		return User;
	}
	public void setUser(User user) {
		User = user;
	}
	@Column(name="QuantityProduitPanier")
	private int QuantityProduitPanier;
	public Cart(int prixCart, Date dateCommande, tn.Dari.ProjetSpring.entities.Product product) {
		super();
		this.prixCart = prixCart;
		this.dateCommande = dateCommande;
		
		Product = product;
	}
	public Date getDateCommande() {
		return dateCommande;
	}
	public void setDateCommande(Date dateCommande) {
		this.dateCommande = dateCommande;
	}
	
	public Product getProduct() {
		return Product;
	}
	public void setProduct(Product product) {
		Product = product;
	}
	@JsonIgnore
	@ManyToOne
	Product Product;
	@JsonIgnore
	@ManyToOne
	private User User;
	@JsonIgnore
	@ManyToOne
	private Orders order;

	public long getIdCart() {
		return idCart;
	}
	public void setIdCart(long idCart) {
		this.idCart = idCart;
	}
	public int getPrixCart() {
		return prixCart;
	}
	public void setPrixCart(int prixCart) {
		this.prixCart = prixCart;
	}
	public Cart() {
		super();
	}
	public Cart(int idCart, int prixCart) {
		super();
		this.idCart = idCart;
		this.prixCart = prixCart;
	}
	public Cart(int QuantityProduitPanier, int prixCart, Date dateCommande, int statusPanier, tn.Dari.ProjetSpring.entities.Product product) {
		super();
		this.prixCart = prixCart;
		this.dateCommande = dateCommande;
		
		this.QuantityProduitPanier=QuantityProduitPanier;
		Product = product;
	}
	public Cart(Cart cart) {
		super();
		this.prixCart = prixCart;
		this.dateCommande = dateCommande;
		
		this.QuantityProduitPanier=QuantityProduitPanier;
		
	}
}
