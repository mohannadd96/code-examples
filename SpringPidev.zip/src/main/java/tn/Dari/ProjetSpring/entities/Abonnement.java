package tn.Dari.ProjetSpring.entities;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Abonnement")
public class Abonnement {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idabonnement")
	private Long idAbonnement;
	@Column(name = "DateDebut")
	@Temporal(TemporalType.DATE)
	private Date dateDebutAbonnement;
	@Column(name = "DateFin")
	@Temporal(TemporalType.DATE)
	private Date dateFinAbonnement;
	@Column(name ="TypeAbonnement")
	private String typeAbonnement;
	@OneToOne(cascade = CascadeType.ALL)
	@JsonIgnore
    @JoinColumn(name = "premiumuser_id", referencedColumnName = "iduser")
	private User premiumuser;
	
	
	/*@OneToMany(cascade=CascadeType.ALL,mappedBy="PremiumUser")
	private List<Mortgage> mortgage; */
	
	public Abonnement() {
		super();
	}


	public Abonnement(Long idAbonnement, Date dateDebutAbonnement, Date dateFinAbonnement, String typeAbonnement,
			User premiumuser) {
		super();
		this.idAbonnement = idAbonnement;
		this.dateDebutAbonnement = dateDebutAbonnement;
		this.dateFinAbonnement = dateFinAbonnement;
		this.typeAbonnement = typeAbonnement;
		this.premiumuser = premiumuser;
	}


	public Long getIdAbonnement() {
		return idAbonnement;
	}


	public void setIdAbonnement(Long idAbonnement) {
		this.idAbonnement = idAbonnement;
	}


	public Date getDateDebutAbonnement() {
		return dateDebutAbonnement;
	}


	public void setDateDebutAbonnement(Date dateDebutAbonnement) {
		this.dateDebutAbonnement = dateDebutAbonnement;
	}


	public Date getDateFinAbonnement() {
		return dateFinAbonnement;
	}


	public void setDateFinAbonnement(Date dateFinAbonnement) {
		this.dateFinAbonnement = dateFinAbonnement;
	}


	public String getTypeAbonnement() {
		return typeAbonnement;
	}


	public void setTypeAbonnement(String typeAbonnement) {
		this.typeAbonnement = typeAbonnement;
	}


	public User getPremiumuser() {
		return premiumuser;
	}


	public void setPremiumuser(User premiumuser) {
		this.premiumuser = premiumuser;
	}
	

}
