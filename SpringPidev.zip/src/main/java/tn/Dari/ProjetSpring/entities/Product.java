package tn.Dari.ProjetSpring.entities;


import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name ="Product")
public class Product implements Serializable{
	public Date getDateProduct() {
		return dateProduct;
	}
	public void setDateProduct(Date dateProduct) {
		this.dateProduct = dateProduct;
	}
	public String getDescriptionProduct() {
		return descriptionProduct;
	}
	public void setDescriptionProduct(String descriptionProduct) {
		this.descriptionProduct = descriptionProduct;
	}
	public Set<Cart> getCart() {
		return cart;
	}
	public void setCart(Set<Cart> cart) {
		this.cart = cart;
	}
	public Set<Wishlist> getWishlist() {
		return wishlist;
	}
	public void setWishlist(Set<Wishlist> wishlist) {
		this.wishlist = wishlist;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="idproduct")
	private Long idProduct;
	@Column(name="nameproduct")
	private String nameProduct;
	@Column(name="imageproduct")
	private String imageProduct;
	@Column(name="priceproduct")
	private int priceProduct;
	
	

	@Column(name="quantityproduct")
	private int quantityProduct;
	@Temporal(TemporalType.DATE)
	@Column(name="dateproduct")
	private Date dateProduct;
	@Column(name="descriptiontproduct")
	private String descriptionProduct;
	@JsonIgnore
	@OneToMany(cascade = CascadeType.ALL, mappedBy="Product")
	private Set<Cart> cart;
	@JsonIgnore
	@OneToMany(cascade = CascadeType.ALL, mappedBy="Product")
	private Set<Wishlist> wishlist;
	@JsonIgnore
	@ManyToOne
	User User;
	

	
	public Product() {
		super();
	}
	@Override
	public String toString() {
		return "Product [idProduct=" + idProduct + ", nameProduct=" + nameProduct + ", imageProduct=" + imageProduct
				+ ", priceProduct=" + priceProduct + ", quantityProduct=" + quantityProduct + ", dateProduct="
				+ dateProduct + ", descriptionProduct=" + descriptionProduct + ", cart=" + cart + ", wishlist="
				+ wishlist + "]";
	}
	public Product(String nameProduct, String imageProduct, int priceProduct, int quantityProduct, Date dateproduct,
			String descriptionProduct) {
		super();
		this.nameProduct = nameProduct;
		this.imageProduct = imageProduct;
		this.priceProduct = priceProduct;
		this.quantityProduct = quantityProduct;
		this.dateProduct = dateproduct;
		this.descriptionProduct = descriptionProduct;
	}
	public Product(Long idProduct, String nameProduct, String imageProduct, int priceProduct, int quantityProduct,
			Date dateproduct, String descriptionProduct) {
		super();
		this.idProduct = idProduct;
		this.nameProduct = nameProduct;
		this.imageProduct = imageProduct;
		this.priceProduct = priceProduct;
		this.quantityProduct = quantityProduct;
		this.dateProduct = dateproduct;
		this.descriptionProduct = descriptionProduct;
	}
	public Long getIdProduct() {
		return idProduct;
	}
	public void setIdProduct(Long idProduct) {
		this.idProduct = idProduct;
	}
	public String getNameProduct() {
		return nameProduct;
	}
	public void setNameProduct(String nameProduct) {
		this.nameProduct = nameProduct;
	}
	public String getImageProduct() {
		return imageProduct;
	}
	public void setImageProduct(String imageProduct) {
		this.imageProduct = imageProduct;
	}
	public int getPriceProduct() {
		return priceProduct;
	}
	public void setPriceProduct(int priceProduct) {
		this.priceProduct = priceProduct;
	}
	public int getQuantityProduct() {
		return quantityProduct;
	}
	public void setQuantityProduct(int quantityProduct) {
		this.quantityProduct = quantityProduct;
	}
	public Date getDateproduct() {
		return dateProduct;
	}
	public void setDateproduct(Date dateproduct) {
		dateProduct = dateproduct;
	}
	public String getDescription() {
		return descriptionProduct;
	}
	public void setDescription(String description) {
		descriptionProduct = description;
	}
	public User getUser() {
		return User;
	}
	public void setUser(User user) {
		User = user;
	}
	
	


}
