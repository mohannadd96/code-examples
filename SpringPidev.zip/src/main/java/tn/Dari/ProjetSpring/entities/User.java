package tn.Dari.ProjetSpring.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "user")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class User implements Serializable , UserDetails{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "iduser")
	private Long idUser;
	@Column(name = "username")
	@NotEmpty(message = "*Please provide a username")
	private String username;
	@NotEmpty(message = "*Please provide a Passowrd")
	@Length(min = 6, message = "*Your passowrd must have at least 6 characters")
	@Column(name = "password")
	private String password;
	@Column(name = "emailuser")
	@NotEmpty(message = "*Please provide an email")
	@Email
	private String emaiUser;
	@Column(name = "adresseuser")
	@NotEmpty(message = "*Please provide your home adresse")
	private String adresseUser;
	@Column(name = "phoneuser")
	@NotNull(message = "Please enter id")
	private Long phoneUser;
	@Column(name = "activeuser")
	private int activeUser;
    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinTable(
            name = "users_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
            )
    private Set<Role> roles = new HashSet<>();
    
    @JsonIgnore
	@OneToMany(cascade=CascadeType.ALL,mappedBy="User")
	private List<Product> product;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="User")
	@JsonIgnore
	private List<Cart> cart;
	@JsonIgnore
	@OneToMany(cascade=CascadeType.ALL,mappedBy="User")
	private List<Wishlist> wishlist;
	@JsonIgnore
	  @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true,mappedBy="user",fetch = FetchType.LAZY)
	    private List<Orders> order;
	@JsonIgnore
	@OneToMany(mappedBy="user")
	private List<Mortgage> mortgages;
	@JsonIgnore
	@OneToMany(fetch = FetchType.EAGER,mappedBy="user")
	private List<Post> posts;

	@JsonIgnore
	@OneToMany(mappedBy="user")
	private List<Asssurance> assurance; 

	@JsonIgnore
	@OneToMany(mappedBy="user")
	private List<Bank> bank; 
	
	public List<Asssurance> getAssurance() {
		return assurance;
	}

	public void setAssurance(List<Asssurance> assurance) {
		this.assurance = assurance;
	}

	public List<Bank> getBank() {
		return bank;
	}

	public void setBank(List<Bank> bank) {
		this.bank = bank;
	}

	public User(Long idUser, @NotEmpty(message = "*Please provide a username") String username,
			@NotEmpty(message = "*Please provide a Passowrd") @Length(min = 6, message = "*Your passowrd must have at least 6 characters") String password,
			@NotEmpty(message = "*Please provide an email") @Email String emaiUser,
			@NotEmpty(message = "*Please provide your home adresse") String adresseUser,
			@NotNull(message = "Please enter id") Long phoneUser,
			int activeUser, Set<Role> roles) {
		super();
		this.idUser = idUser;
		this.username = username;
		this.password = password;
		this.emaiUser = emaiUser;
		this.adresseUser = adresseUser;
		this.phoneUser = phoneUser;
		this.activeUser = activeUser;
		this.roles = roles;
	}

	public Long getIdUser() {
		return idUser;
	}

	public void setIdUser(Long idUser) {
		this.idUser = idUser;
	}

	public void setusername(String username) {
		this.username = username;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	public String getEmaiUser() {
		return emaiUser;
	}

	public void setEmaiUser(String emaiUser) {
		this.emaiUser = emaiUser;
	}

	public String getAdresseUser() {
		return adresseUser;
	}

	public void setAdresseUser(String adresseUser) {
		this.adresseUser = adresseUser;
	}

	public Long getPhoneUser() {
		return phoneUser;
	}

	public void setPhoneUser(Long phoneUser) {
		this.phoneUser = phoneUser;
	}

	public int getActiveUser() {
		return activeUser;
	}

	public void setActiveUser(int activeUser) {
		this.activeUser = activeUser;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
        Set<Role> roles = getRoles();
        List<SimpleGrantedAuthority> authorities = new ArrayList<>();
         
        for (Role role : roles) {
            authorities.add(new SimpleGrantedAuthority(role.getName()));
        }
         
        return authorities;
	}
	
	

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return password;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return username;
	}	

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public List<Cart> getCart() {
		return cart;
	}

	public void setCart(List<Cart> cart) {
		this.cart = cart;
	}

	public List<Wishlist> getWishlist() {
		return wishlist;
	}

	public void setWishlist(List<Wishlist> wishlist) {
		this.wishlist = wishlist;
	}

	public List<Orders> getOrder() {
		return order;
	}

	public void setOrder(List<Orders> order) {
		this.order = order;
	}

	public List<Post> getPosts() {
		return posts;
	}

	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}


	public User() {
		super();
	}

	public List<Mortgage> getMortgages() {
		return mortgages;
	}

	public void setMortgages(List<Mortgage> mortgages) {
		this.mortgages = mortgages;
	}




	
	
	
	
	
	
}