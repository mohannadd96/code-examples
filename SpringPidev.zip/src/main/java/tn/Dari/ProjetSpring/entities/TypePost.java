package tn.Dari.ProjetSpring.entities;

public enum TypePost {
	RENT,SELL;

}
