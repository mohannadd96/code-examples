package tn.Dari.ProjetSpring.entities;

import java.time.LocalTime;
//import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
//import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name="meeting")
public class Meeting {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idmeeting")
	private Long idMeeting;

	@Column(name = "nameMeeting")
	private String nameMeeting;
	
	@Column(name = "urlmeeting")
	private String urlmeeting;
	
	@Column(name="timemeeting")
	@Temporal(TemporalType.TIME)

	private Date timemeeting;
	
	
	public String getUrlmeeting() {
		return urlmeeting;
	}

	public void setUrlmeeting(String urlmeeting) {
		this.urlmeeting = urlmeeting;
	}

	public Date getTimemeeting() {
		return timemeeting;
	}

	public void setTimemeeting(Date timemeeting) {
		this.timemeeting = timemeeting;
	}

	public String getNameMeeting() {
		return nameMeeting;
	}

	public void setNameMeeting(String nameMeeting) {
		this.nameMeeting = nameMeeting;
	}

	@Column(name="datemeeting")
	@Temporal(TemporalType.DATE)

	private Date dateMeeting;
	@JsonIgnore
	@ManyToOne
	private Post Post;
	
	/*private LocalTime meetingTime;*/
	/*
	@ManyToOne(cascade = CascadeType.ALL,mappedBy="Users")
	private  Set<Dbo_User> list_users;*/
	/*
	@ManyToOne(cascade = CascadeType.ALL,mappedBy="Posts")
	private  Set<Dbo_Post> list_Posts;*/

	public Long getIdMeeting() {
		return idMeeting;
	}

	public void setIdMeeting(Long idMeeting) {
		this.idMeeting = idMeeting;
	}

	public Date getDateMeeting() {
		return dateMeeting;
	}

	public void setDateMeeting(Date dateMeeting) {
		this.dateMeeting = dateMeeting;
	}

	
	
	public Meeting(Long idMeeting, String nameMeeting,Date dateMeeting) {
		super();
		this.idMeeting = idMeeting;
		this.nameMeeting = nameMeeting;
		this.dateMeeting = dateMeeting;
	}

	public Meeting(Long idMeeting, Date dateMeeting) {
		
		this.idMeeting = idMeeting;
		this.dateMeeting = dateMeeting;
	}

	public Meeting() {
		super();
	}

	public Post getPost() {
		return Post;
	}

	public void setPost(Post post) {
		Post = post;
	}

	@Override
	public String toString() {
		return "Meeting [idMeeting=" + idMeeting + ", nameMeeting=" + nameMeeting + ", dateMeeting=" + dateMeeting
				+ ", Post=" + Post + "]";
	}
	
	
	
	
}
