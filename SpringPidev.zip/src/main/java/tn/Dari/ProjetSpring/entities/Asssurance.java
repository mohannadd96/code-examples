package tn.Dari.ProjetSpring.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
//import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "assurance")
public class Asssurance implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idassurance")
	private Long idAssurance;

	@Column(name = "nameassurance")
	// @NotEmpty(message = "*Please provide an Assurance name")
	private String nameAssurance;

	@Column(name = "typeassurance")
	// @NotEmpty(message = "*Please provide an Assurance type")
	private String typeAssurance;

	@Column(name = "adressassurance")
	// @NotEmpty(message = "*Please provide an Assurance adress")
	private String adressAssurance;

	@Column(name = "pictureassurance")
	// @NotEmpty(message = "*Please provide an Assurance picture")
	private String pictureAssurance;
	@JsonIgnore
	@ManyToOne
	private User user;
	@JsonIgnore
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "assurance")
	private Set<Contract> contracts;

	public Long getIdAssurance() {
		return idAssurance;
	}

	public void setIdAssurance(Long idAssurance) {
		this.idAssurance = idAssurance;
	}

	public String getNameAssurance() {
		return nameAssurance;
	}

	public void setNameAssurance(String nameAssurance) {
		this.nameAssurance = nameAssurance;
	}

	public String getTypeAssurance() {
		return typeAssurance;
	}

	public void setTypeAssurance(String typeAssurance) {
		this.typeAssurance = typeAssurance;
	}

	public String getAdressAssurance() {
		return adressAssurance;
	}

	public void setAdressAssurance(String adressAssurance) {
		this.adressAssurance = adressAssurance;
	}

	public String getPictureAssurance() {
		return pictureAssurance;
	}

	public void setPictureAssurance(String pictureAssurance) {
		this.pictureAssurance = pictureAssurance;
	}

	public Set<Contract> getContracts() {
		return contracts;
	}

	public void setContracts(Set<Contract> contracts) {
		this.contracts = contracts;
	}



	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Asssurance(Long idAssurance, String nameAssurance, String typeAssurance, String adressAssurance,
			String pictureAssurance, Set<Contract> contracts) {
		this.idAssurance = idAssurance;
		this.nameAssurance = nameAssurance;
		this.typeAssurance = typeAssurance;
		this.adressAssurance = adressAssurance;
		this.pictureAssurance = pictureAssurance;
		this.contracts = contracts;
	}

	public Asssurance(){

	}
}
