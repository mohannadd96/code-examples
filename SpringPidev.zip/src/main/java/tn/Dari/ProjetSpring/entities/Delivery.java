package tn.Dari.ProjetSpring.entities;

import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.Email;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
public class Delivery {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="iddelivery")
	private int idDelivery;
	
	@Column(name="addressdelivery")
	private String addressDelivery;
	
	@Column(name="feesdelivery")
	private int feesDelivery;
	
	@Temporal(TemporalType.DATE)
	@Column(name="datedelivery")
	private Date dateDelivery;
	
	@Column(name="etatdelivery")
	private boolean etatDelivery;
	
	@Email(message = "Email should be valid")
	@Column(name="emaildelivery")
    private String emailDelivery;
	
	@Column(name="idclientdelivery")
    private long idClientDelivery;
	
	@JsonIgnore
	@ManyToOne
	private DeliveryMan DeliveryMan;
	
	public Delivery() {
		super();
	}
	public Delivery(String addressDelivery, int feesDelivery) {
		super();
		this.addressDelivery = addressDelivery;
		this.feesDelivery = feesDelivery;
	}

	
	
	public Delivery(int idDelivery, String addressDelivery, int feesDelivery, Date dateDelivery, boolean etatDelivery,
			tn.Dari.ProjetSpring.entities.DeliveryMan deliveryMan) {
		super();
		this.idDelivery = idDelivery;
		this.addressDelivery = addressDelivery;
		this.feesDelivery = feesDelivery;
		this.dateDelivery = dateDelivery;
		this.etatDelivery = etatDelivery;
		DeliveryMan = deliveryMan;
	}
	public boolean getEtatDelivery() {
		return etatDelivery;
	}
	public void setEtatDelivery(boolean etatDelivery) {
		this.etatDelivery = etatDelivery;
	}
	public DeliveryMan getDeliveryMan() {
		return DeliveryMan;
	}
	public void setDeliveryMan(DeliveryMan deliveryMan) {
		DeliveryMan = deliveryMan;
	}
	public void setIdDelivery(int idDelivery) {
		this.idDelivery = idDelivery;
	}
	public int getIdDelivery() {
		return idDelivery;
	}
	
	public String getAddressDelivery() {
		return addressDelivery;
	}
	public void setAddressDelivery(String addressDelivery) {
		this.addressDelivery = addressDelivery;
	}
	public int getFeesDelivery() {
		return feesDelivery;
	}
	public void setFeesDelivery(int feesDelivery) {
		this.feesDelivery = feesDelivery;
	}
	public Date getDateDelivery() {
		return dateDelivery;
	}
	public void setDateDelivery(Date dateDelivery) {
		this.dateDelivery = dateDelivery;
	}
	public String getEmailDelivery() {
		return emailDelivery;
	}
	public void setEmailDelivery(String emailDelivery) {
		this.emailDelivery = emailDelivery;
	}
	public long getIdClientDelivery() {
		return idClientDelivery;
	}
	public void setIdClientDelivery(long idClientDelivery) {
		this.idClientDelivery = idClientDelivery;
	}
	
	

}
