package tn.Dari.ProjetSpring.Services;

import java.util.List;
import java.util.Optional;

import tn.Dari.ProjetSpring.entities.Role;

public interface IRoleService {
	
	public Role addUser (Role role);
	public void DeleteRole(Long idUser);
	public void UpdateRole(Long id , Long user);

}
