package tn.Dari.ProjetSpring.Services;

import java.util.List;

import tn.Dari.ProjetSpring.entities.DeliveryManNote;

public interface DeliveryManNoteImp {

	public List<DeliveryManNote> getAllDeliveryManNote();
	public void saveOrUpdate(DeliveryManNote deliverymannote);
	public void deleteDeliveryManNote(int id);
}
