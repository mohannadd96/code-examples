package tn.Dari.ProjetSpring.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpSession;

import org.apache.commons.math3.*;
import org.apache.commons.math3.util.MathUtils;

import tn.Dari.ProjetSpring.Repositories.BankRepository;
import tn.Dari.ProjetSpring.Repositories.MortgageRepository;
import tn.Dari.ProjetSpring.Repositories.PostRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.entities.Bank;
import tn.Dari.ProjetSpring.entities.Mortgage;
import tn.Dari.ProjetSpring.entities.Post;
import tn.Dari.ProjetSpring.entities.User;

@Service
@Transactional
public class MortgageService  implements IMortgageService{
	@Autowired
	MortgageRepository mr;
	@Autowired
	BankRepository br;
	@Autowired
	PostRepository pr;
	@Autowired
	UserRepository ur;
	@Autowired
	HttpSession session;
	
	@Override
	public double calculMortgage(Mortgage mortgage, int idp, Long idb) {
			Post p= pr.findById(idp).get();
			Bank b=br.findById(idb).get();
			Long id=(Long)session.getAttribute("name");	 
			User u=ur.findById(id).get();
			mortgage.setBank(b);
			mortgage.setPost(p);
			mortgage.setNameMortgage(u.getUsername()+"/"+u.getIdUser());
			mr.save(mortgage);
			int nb =mortgage.getNbAnneeMortgage();
			double Montant= p.getPricePost()*0.8;
			double ti=b.getTMM()+b.getMarge();
			double a = Math.pow((1+ti),-nb);
			double mfy=Montant*(ti/(1-a));
			/*double ac[]  =new double[nb];
			for(int i=1;i<nb;i++)
			{
				if(i==1)
				{
				ac[i]=mfy*(1-ti);
				System.out.println(ac[i]);
				}
				else{
					ac[i]=ac[i-1]*(1-ti);
					System.out.println(ac[i]);
				}
				
			}
			double s=mfy;
			for(int i=0;i<nb-1;i++)
			{
				s+=ac[i];
			}
			System.out.println(s);*/
			if(b.getStatutsBank()==1)
			{
				return  mfy; 
			}
			else
			{
				return 0;
			}

		
	}
	@Override
	public ResponseEntity<?> compare(Mortgage mortgage, int idp, Long idb) {
		double a= (calculMortgage(mortgage, idp, idb)/12)/0.4;
		System.out.println(a);
		if (mortgage.getSalaryMortgage()<(a-0.5))
		{
			return new ResponseEntity<>("You can't have this Credit", HttpStatus.CREATED);	
		}
		else 
		{
			return new ResponseEntity<>("You can have this Credit", HttpStatus.CREATED);	
		}
	}
	
	

}
