package tn.Dari.ProjetSpring.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tn.Dari.ProjetSpring.Repositories.ProductRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.User;

@Service
@Transactional
public class ServiceUser {
	@Autowired
	UserRepository UserRepositroy;
	public User getByid(Long id) {
		// TODO Auto-generated method stub
		return UserRepositroy.findById(id).get();
	}

}
