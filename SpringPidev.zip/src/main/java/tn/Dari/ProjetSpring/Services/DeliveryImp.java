package tn.Dari.ProjetSpring.Services;

import java.util.List;

import tn.Dari.ProjetSpring.entities.Delivery;


public interface DeliveryImp {
	
		public List<Delivery> getAllDelivery();
		public  Delivery getByid(int id);
		public void saveOrUpdate(Delivery delivery);
		public void affect(int idd,int id);
		public void deleteDelivery(int id);
		public Delivery updateDelivery(int id, Delivery delivery);
		public void checkDelivery(int id);
	
}
