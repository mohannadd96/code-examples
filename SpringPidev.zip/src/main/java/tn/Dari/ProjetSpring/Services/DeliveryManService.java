package tn.Dari.ProjetSpring.Services;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tn.Dari.ProjetSpring.Repositories.DeliveryManRepository;
import tn.Dari.ProjetSpring.Repositories.DeliveryManNoteRepository;
import tn.Dari.ProjetSpring.Repositories.PostRepository;
import tn.Dari.ProjetSpring.entities.Delivery;
import tn.Dari.ProjetSpring.entities.DeliveryMan;
import tn.Dari.ProjetSpring.entities.DeliveryManNote;
import tn.Dari.ProjetSpring.entities.Post;
@Service
@Transactional
public class DeliveryManService implements DeliveryManImp {
	@Autowired 
	DeliveryManRepository DeliveryManRepository;
	@Autowired 
	DeliveryManNoteRepository DeliveryManNoteRepository;

	@Override
	public List<DeliveryMan> getAllDeliveryMan() {
		// TODO Auto-generated method stub
		return DeliveryManRepository.findAll();
	}

	@Override
	public DeliveryMan getByid(int id) {
		// TODO Auto-generated method stub
		return DeliveryManRepository.findById(id).get();
	}

	@Override
	public void saveOrUpdate(DeliveryMan deliveryman) {
		// TODO Auto-generated method stub
		deliveryman.setEtatDeliveryMan(true);
		DeliveryManRepository.save(deliveryman);
	}

	@Override
	public void deleteDeliveryMan(int id) {
		// TODO Auto-generated method stub
		DeliveryManRepository.deleteById(id);
	}

	@Override
	public DeliveryMan updateDeliveryMan(int id, DeliveryMan deliveryman) {
		// TODO Auto-generated method stub
		DeliveryMan DeliveryMan1 = DeliveryManRepository.findById(id).get();
		DeliveryMan1.setTelDeliveryMan(deliveryman.getTelDeliveryMan());
		
		return DeliveryManRepository.save(DeliveryMan1);
	}

	public void rate() {
		List<Integer> d =DeliveryManRepository.iddm();
		 List<DeliveryMan> dm = DeliveryManRepository.findAll();
		 List<DeliveryManNote> dmn = DeliveryManNoteRepository.findAll();
		//for(int i = 0 ; i < d.size(); i++){
		
		//DeliveryManNote dmn = DeliveryManNoteRepository.findById(d.get(i)).get();
		
		for (Iterator<DeliveryMan> it = dm.iterator(); it.hasNext();)
			// for(int i = 0 ; i < dm.size(); i++)
			 {
		       
				DeliveryMan dmm =  it.next();
				for (Iterator<DeliveryManNote> il = dmn.iterator(); il.hasNext();)
					 //for(int i = 0 ; i < dm.size(); i++)
					 {
				       
						DeliveryManNote dmnn =  il.next();
						if(dmm.getIdDeliveryMan()==(int)dmnn.getIdDeliveryManNote()){
							//for(int i = 0 ; i < d.size(); i++){
								//DeliveryMan dmu = DeliveryManRepository.findById(d.get(i)).get();
		//if(dmn.getIdDeliveryManNote()==)
		float rate = DeliveryManRepository.insertRate((long)dmm.getIdDeliveryMan());
		dmm.setRateDeliveryMan(rate);
						if(rate<5)
						{ dmm.setEtatDeliveryMan(false);
						DeliveryManRepository.save(dmm);
						}
		//System.out.println(rate+"*********************");
						else	DeliveryManRepository.save(dmm);
							
						}
						
						
			 }
		}
		
	}

}
