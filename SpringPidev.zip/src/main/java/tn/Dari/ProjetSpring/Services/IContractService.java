package tn.Dari.ProjetSpring.Services;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.itextpdf.text.DocumentException;

import tn.Dari.ProjetSpring.entities.Contract;

public interface IContractService {
	public Contract addContract (Contract contract,Long id);
	public List<Contract> getAllContract();
	public ResponseEntity<?> generateContract(Long id) throws IOException, URISyntaxException, DocumentException;
}
