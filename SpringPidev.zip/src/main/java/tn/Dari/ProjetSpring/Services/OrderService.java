package tn.Dari.ProjetSpring.Services;

import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.ImgCCITT;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfWriter;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;

import tn.Dari.ProjetSpring.Repositories.CartRepository;
import tn.Dari.ProjetSpring.Repositories.OrderRepository;
import tn.Dari.ProjetSpring.entities.Cart;

import tn.Dari.ProjetSpring.entities.Orders;

import tn.Dari.ProjetSpring.entities.User;
import tn.Dari.ProjetSpring.entities.checkoutItemDto;
@Service
@Transactional 
public class OrderService {
	@Autowired
	CartService CartService;
	
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	ServiceUser UserService;
	
	@Value("${baseURL}")
	private String baseURL;

	@Value("${STRIPE_SECRET_KEY}")
	private String apiKey;
	SessionCreateParams.LineItem.PriceData createPriceData(checkoutItemDto checkoutItemDto ) {
		return SessionCreateParams.LineItem.PriceData.builder().setCurrency("usd")
				.setUnitAmount(((long) checkoutItemDto.getPrice()) * 100)
				.setProductData(SessionCreateParams.LineItem.PriceData.ProductData.builder()
						.setName(checkoutItemDto.getProductName()).build())
				.build();
	}

	SessionCreateParams.LineItem createSessionLineItem(checkoutItemDto checkoutItemDto) {
		return SessionCreateParams.LineItem.builder().setPriceData(createPriceData(checkoutItemDto))
				.setQuantity(Long.parseLong(String.valueOf(checkoutItemDto.getQuantity()))).build();
	}

	public Session createSession(long user) throws StripeException {
		List<Cart> cartDto = CartService.getByUser(user);
	//	List<CartItemDto> cartItemDtoList = cartDto.getcartItems();
		String successURL = baseURL + "payment/success";
		String failedURL = baseURL + "payment/failed";
		Stripe.apiKey = apiKey;
		List<SessionCreateParams.LineItem> sessionItemsList = new ArrayList<SessionCreateParams.LineItem>();
		for (Cart cartItemDto : cartDto) {
			checkoutItemDto CheckoutItemDto = new checkoutItemDto(cartItemDto.getProduct().getNameProduct(),
					cartItemDto.getQuantityProduitPanier(), cartItemDto.getProduct().getPriceProduct(), cartItemDto.getProduct().getIdProduct(),
					cartItemDto.getUser().getIdUser());
			sessionItemsList.add(createSessionLineItem(CheckoutItemDto));
		}

		SessionCreateParams params = SessionCreateParams.builder()
				.addPaymentMethodType(SessionCreateParams.PaymentMethodType.CARD)
				.setMode(SessionCreateParams.Mode.PAYMENT).setCancelUrl(failedURL).addAllLineItem(sessionItemsList)
				.setSuccessUrl(successURL).build();
		return Session.create(params);
	}
	public int saveOrder(int orderDto, User userId, String sessionID,Date d,String adresse){
		
        Orders order = getOrderFromDto(orderDto,userId,sessionID,d,adresse);
        return orderRepository.save(order).getIdOrder();
        
    }
	 private Orders getOrderFromDto(int orderDto, User userId,String sessionID,Date d,String adresse) {
	        Orders order = new Orders (orderDto,userId,sessionID,d,adresse);
	        return order;
	    }
	  public void addOrderedProducts(Orders orderItem) {
	        orderRepository.save(orderItem);
	    }
	
	public void placeOrder(User user, String sessionId) {
		
		System.out.println(user.getIdUser());
 //User u=	UserService.getByid(user.getIdUser());

	
		List<Cart>  cartDto = CartService.getByUser(user.getIdUser());
	
		
		Orders placeOrderDto = new Orders();
		Calendar currentDate = Calendar.getInstance();
		Date d = currentDate.getTime();
	
		placeOrderDto.setUser(user);
		System.out.println(d+"xxxxxxxxxxxxxxxxxxxxxxxxxxx");
	placeOrderDto.setTotalPrice(CartService.SUMPRODUIT(user.getIdUser()));
	placeOrderDto.setCreatedDate(d);
	placeOrderDto.setAdresse(user.getAdresseUser());
	System.out.println(CartService.SUMPRODUIT(user.getIdUser()));
	System.out.println(placeOrderDto.getAdresse());
		saveOrder(placeOrderDto.getTotalPrice(),user, sessionId,d,placeOrderDto.getAdresse());
		
		
		

		
		Document document = new Document();
		document.setPageSize(PageSize.A5);
		Font redFont = FontFactory.getFont("Times-Roman", 16, Font.BOLD);
		redFont.setColor(55, 55, 55);
		try
		{
			for (Cart cartItemDto : cartDto) {
				checkoutItemDto CheckoutItemDto = new checkoutItemDto(cartItemDto.getProduct().getNameProduct(),
						cartItemDto.getQuantityProduitPanier(), cartItemDto.getProduct().getPriceProduct(), cartItemDto.getProduct().getIdProduct(),
						cartItemDto.getUser().getIdUser());
				createSessionLineItem(CheckoutItemDto);
				System.out.println(cartItemDto.getProduct().getIdProduct());
			}
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Facture.pdf"));
			document.open();
			placeOrderDto.setUser(user);
         
           
    		

    		
			//Paragraph with color and font styles
			Paragraph paragraphOne = new Paragraph("          FACTURE DU CLIENT ID:  0000000"+user.getIdUser(), redFont);
			document.add(paragraphOne);
			for (Cart cartItemDto : cartDto) {
				checkoutItemDto CheckoutItemDto = new checkoutItemDto(cartItemDto.getProduct().getNameProduct(),
						cartItemDto.getQuantityProduitPanier(), cartItemDto.getProduct().getPriceProduct(), cartItemDto.getProduct().getIdProduct(),
						cartItemDto.getUser().getIdUser());
				createSessionLineItem(CheckoutItemDto);
				System.out.println(cartItemDto.getProduct().getIdProduct());
				// Path path = Paths.get(ClassLoader.getSystemResource("C:\\wamp64\\www\\ImageDari\\"+cartItemDto.getProduct().getImageProduct()).toURI());
		    		Image img = Image.getInstance("C:\\xampp\\image_app\\"+cartItemDto.getProduct().getImageProduct());
		    	
		    		img.scaleToFit(200,200);
		    		document.add(img);
			
				Paragraph produit = new Paragraph("\n  Nom Du Produit:  "+cartItemDto.getProduct().getNameProduct()+"\n  PRIX:  "+cartItemDto.getProduct().getPriceProduct()*10+" DT");
				
				document.add(produit);
				
				
			
			}
			

			//Create chapter and sections
			Paragraph chapterTitle = new Paragraph("  \n \n \n \n \n \n \n \n                                                          total : "+placeOrderDto.getTotalPrice()*10+" DT", redFont);
			 
			
			
			
			document.add(chapterTitle);
		

			document.close();
			writer.close();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	
 //CartService.SupprimerallCart(user.getIdUser());
		
		
		

		
	
	}
	
}
