package tn.Dari.ProjetSpring.Services;

import org.springframework.http.ResponseEntity;

import tn.Dari.ProjetSpring.entities.Mortgage;

public interface IMortgageService {
	public double calculMortgage(Mortgage mortgage,int idp,Long idb);
	public ResponseEntity<?> compare(Mortgage mortgage,int idp,Long idb);
	
}
