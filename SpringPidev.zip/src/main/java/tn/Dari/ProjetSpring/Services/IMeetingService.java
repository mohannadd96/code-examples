package tn.Dari.ProjetSpring.Services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import tn.Dari.ProjetSpring.entities.Meeting;

public interface IMeetingService
{
public Meeting addMeeting(Meeting meeting ,int id);
public Meeting updateMeeting(Long id,Meeting meeting);
public ResponseEntity<?> deleteMeeting(Long id);
public List<Meeting> getAllMeeting();
public  List<Meeting> SMSMeeting();
}