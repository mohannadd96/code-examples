package tn.Dari.ProjetSpring.Services;


import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import tn.Dari.ProjetSpring.Repositories.BankRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.entities.Bank;
import tn.Dari.ProjetSpring.entities.User;
@Component
@Service
@Transactional
public class BankService implements IBankService {
	@Autowired
	BankRepository br;
	@Autowired
	JavaMailSender javaMailSender;
	@Autowired
	UserRepository ur;
	@Autowired
	HttpSession session;
	@Override
	public Bank addBank(Bank bank) {
		Long named=(Long)session.getAttribute("name");	 
		User a=ur.findById(named).get();

		Calendar currentDate = Calendar.getInstance();
		Date d = currentDate.getTime();
		bank.setDateInsert(d);
		currentDate.setTime(d);
		currentDate.add(Calendar.MONTH, 1);
		Date d1 = currentDate.getTime();
		bank.setDatePrevu(d1);
		bank.setStatutsBank(1);
		bank.setUser(a);;
		return br.save(bank);

	}

	@Override
	public Bank updateBank(Long id, Bank bank) {
		Bank bank1 = br.findById(id).get();

		bank1.setNameBank(bank.getNameBank());
		bank1.setAdressBank(bank.getAdressBank());
		return br.save(bank1);
		 

	}

	@Override
	public ResponseEntity<?> deleteBank(Long id) {
		br.delete(br.findById(id).get());
		return new ResponseEntity<>("Bank Deleted successfully", HttpStatus.CREATED);

	}

	@Override
	public List<Bank> getAllBank() {
		return (List<Bank>) br.findAll();
	}


	//@Scheduled(cron = "* 1 * * * ?")
	@Override
	public Bank check() {

		Calendar currentdate = Calendar.getInstance();
		Date d = currentdate.getTime();
		System.out.println(d);
		Bank b = br.findByDatefin(d);
		SimpleMailMessage mail = new SimpleMailMessage();

		mail.setTo(b.getUser().getEmaiUser());

		mail.setSubject("change tMM");
		mail.setText("la banque de nom " + b.getNameBank() + " n'est pas a jour");

		javaMailSender.send(mail);
		return b;

	}

	@Override
	public List<Bank> disable() {
		Calendar currentdate = Calendar.getInstance();
		currentdate.add(Calendar.DAY_OF_MONTH, -60);
		Date d1 =currentdate.getTime();
		List<Bank> b =br.findByDatefinlist(d1);
		SimpleMailMessage mail = new SimpleMailMessage();
		for(Bank banks :b)
		{
			mail.setTo(banks.getUser().getEmaiUser());

			mail.setSubject("a bank has been disabled");
			mail.setText("la banque de nom " + banks.getNameBank() + " has been disable because u didnt change the TMM value please change it then enable it ");

			javaMailSender.send(mail);
				banks.setStatutsBank(0);
		}
		return (List<Bank>) br.saveAll(b);
	}

	@Override
	public ResponseEntity<?> enable(Long id) {
		Bank b= br.findById(id).get();

		b.setStatutsBank(1);
		br.save(b);
		return new ResponseEntity<>("bank enabled successfully", HttpStatus.CREATED);
		

	}
	
	

}
