package tn.Dari.ProjetSpring.Services;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tn.Dari.ProjetSpring.Repositories.ProductRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.User;

@Service
@Transactional
public class ProductService  implements ProductServiceImp{
	@Autowired
	ProductRepository ProductRepositroy;
	@Autowired
	UserRepository UserRepositroy;

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return ProductRepositroy.findAll();
		
	}

	

	@Override
	public List<Product> getByid(Long id) {
	
		// TODO Auto-generated method stub
		return ProductRepositroy.ListProductByUser(id);
	}

	@Override
	public void saveOrUpdate(Product product) {
		
		
		ProductRepositroy.save(product);
		
	}

	@Override
	public void deleteProduct(Long id,Long idUser) {
		// TODO Auto-generated method stub
		Product Product1 = ProductRepositroy.findById(id).get();
	 	if (idUser==Product1.getUser().getIdUser()){
		ProductRepositroy.deleteById(id);
	 	}
	}
	@Override
	public List<Product> findByName(String name) {		
		return (List<Product>) ProductRepositroy.findByNameAssurance(name);
	}
	@Override
	public Product updateProduct(Long id,Long idUser, Product Product) {
		
		 	Product Product1 = ProductRepositroy.findById(id).get();
		 	if (idUser==Product1.getUser().getIdUser()){
		 	Product1.setNameProduct(Product.getNameProduct());
		 	Product1.setDateProduct(Product.getDateProduct());
		 	Product1.setImageProduct(Product.getImageProduct());
		 	Product1.setPriceProduct(Product.getPriceProduct());
		 	Product1.setQuantityProduct(Product.getQuantityProduct());
		 	Product1.setDescriptionProduct(Product.getDescriptionProduct());
		 return ProductRepositroy.save(Product1);
		 	}
		 	return ProductRepositroy.save(Product1);
	}
}
