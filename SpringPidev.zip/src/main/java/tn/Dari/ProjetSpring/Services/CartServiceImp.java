package tn.Dari.ProjetSpring.Services;

import java.util.List;

import tn.Dari.ProjetSpring.entities.Cart;
import tn.Dari.ProjetSpring.entities.Product;


public interface CartServiceImp {
	public List<Cart> getAllCart();
	public  Cart getByid(long id);
	public Cart saveCart(Cart cart,long id,long iduser);
	public int SUMPRODUIT(Long id);
	public void deleteCart(long id);
	

}
