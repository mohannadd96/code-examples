package tn.Dari.ProjetSpring.Services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.apache.catalina.startup.ClassLoaderFactory.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import tn.Dari.ProjetSpring.Configurations.SmsRequest;
import tn.Dari.ProjetSpring.Configurations.TwilioSmsSender;
import tn.Dari.ProjetSpring.Repositories.MeetingRespository;
import tn.Dari.ProjetSpring.Repositories.PostRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.entities.Meeting;
import tn.Dari.ProjetSpring.entities.Post;
import tn.Dari.ProjetSpring.entities.TypePost;
import tn.Dari.ProjetSpring.entities.User;

@Service
@Transactional
public class MeetingService implements IMeetingService  {
	@Autowired
	TwilioSmsSender sms;
	
	@Autowired
	UserRepository userRepository;
@Autowired
MeetingRespository me;
@Autowired
PostRepository pr;
@Autowired
private JavaMailSender javaMailSender;
	
/*function for adding a meet with user and landloard*/
@Override
	public Meeting addMeeting (Meeting meeting,int id) {
		Post post = pr.findById(id).get();
		meeting.setPost(post);
		SimpleMailMessage msg = new SimpleMailMessage();
		    msg.setTo(post.getUser().getEmaiUser());

		    msg.setSubject("hello "+post.getUser().getUsername());
		    msg.setText("you have a meet at "+meeting.getDateMeeting()+"the time of your meeting is "+meeting.getTimemeeting()+" thank you "
		    		+"you will recive a text before one day of the meeting to remind you");

		    javaMailSender.send(msg);
			 return meeting= me.save(meeting);
			

	}
	
	
/*function for updating a meet with user and landloard*/

	@Override
	public Meeting updateMeeting(Long id, Meeting meeting) {
			
		Meeting meeting1 = me.findById(id).get();
		meeting1.setNameMeeting(meeting.getNameMeeting());
		meeting1.setDateMeeting(meeting.getDateMeeting());
		meeting1.setUrlmeeting(meeting1.getUrlmeeting());
		meeting1.setTimemeeting(meeting.getTimemeeting());
		 return me.save(meeting1); 
		 
		
	}
	
	@Override
	public ResponseEntity<?> deleteMeeting(Long id) {
		Meeting meeting = me.findById(id).get();
			me.delete(meeting);
			return ResponseEntity.ok().build();
	}
	@Override
	public List<Meeting> getAllMeeting() {
		return (List<Meeting>) me.findAll();
	}
	/*function for search  of meeting for user connected*/

public List<Meeting> MeetingUser (Long id_user)
{
	User user = userRepository.findById(id_user).get();
	
List<Meeting>meetings = new ArrayList<>();
	for (Post post : user.getPosts()) {
		
		for (Meeting meeting : post.getMeeting()) {
			meetings.add(meeting);
		}
	}
	return meetings;
	
}
/*function for showing only the postsell type */

public List<Post> afficherpostsell()
{
	
List<Post> posts_sell = new ArrayList<>();
	for (Post post :pr.findAll()) {
		
	if(post.getTypePost().equals(TypePost.SELL))
	{
		posts_sell.add(post);
		
	}
	}
	return posts_sell;
	
}
/*function for showing only the postrent type */

public List<Post> afficherpostrent()
{
	
List<Post> posts_rent = new ArrayList<>();
	for (Post post :pr.findAll()) {
		
	if(post.getTypePost().equals(TypePost.RENT))
	{
		posts_rent.add(post);
		
	}
	}
	return posts_rent;
	
}

/*function for sending a sms for the user before one day */


@Override
public List<Meeting> SMSMeeting() {
	
	Calendar currentdate = Calendar.getInstance();
	currentdate.add(Calendar.DATE,1);
	Date d1 =currentdate.getTime();
	System.out.println("");
	System.out.println(d1);
	List<Meeting> b =me.findByDateMeeting(d1);
	Date current_date = new Date();

	for(Meeting meets :me.findAll())
	{  int i= current_date.getDate()-meets.getDateMeeting().getDate() ;
	System.out.println(i);
		if( i== -1)
		{	
		SmsRequest s=new SmsRequest("+21658675516", "hello"+meets.getPost().getUser().getUsername()+"\n"+
				"you have a meet"+meets.getNameMeeting()+"tomorrow at"+meets.getDateMeeting()+"the url of the meet is "+meets.getUrlmeeting());
		
	sms.sendSms(s);
	}
	}
	return me.saveAll(b);	

}
}
