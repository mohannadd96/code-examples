package tn.Dari.ProjetSpring.Services;

import tn.Dari.ProjetSpring.entities.PasswordResetToken;
import tn.Dari.ProjetSpring.entities.User;

public interface IPasswordTokenService {
	
	public PasswordResetToken create (PasswordResetToken PasswordResetToken) ;
}
