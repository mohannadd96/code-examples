package tn.Dari.ProjetSpring.Services;

import java.util.List;
import java.util.Optional;

import tn.Dari.ProjetSpring.entities.Abonnement;

public interface IAbonnementService {
	
	public Abonnement addAbonnement (Abonnement abonnement);
	public void deleteAbonnement (Long id);
	public List<Abonnement> showAbonnement ();
	public Optional<Abonnement> showAbonnementbyid ();

}
