package tn.Dari.ProjetSpring.Services;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import tn.Dari.ProjetSpring.entities.Asssurance;

public interface IAssuranceService {
public Asssurance addAssurance(Asssurance assurance);
public Asssurance updateAssurance(Long id,Asssurance assurance);
public ResponseEntity<?> deleteAssurance(Long id);
public List<Asssurance> getAllAssurance();
public List<Asssurance> findByName(String name);
}
