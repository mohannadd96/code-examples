package tn.Dari.ProjetSpring.Services;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tn.Dari.ProjetSpring.Repositories.DeliveryManNoteRepository;
import tn.Dari.ProjetSpring.Repositories.DeliveryManRepository;
import tn.Dari.ProjetSpring.Repositories.DeliveryRepository;
import tn.Dari.ProjetSpring.entities.Delivery;
import tn.Dari.ProjetSpring.entities.DeliveryMan;
import tn.Dari.ProjetSpring.entities.DeliveryManNote;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletOutputStream;

@Service
@Transactional
public class DeliveryManNoteService implements DeliveryManNoteImp{
	@Autowired 
	DeliveryManNoteRepository DeliveryManNoteRepository;
	DeliveryManRepository DeliveryManRepository;
	DeliveryRepository DeliveryRepository ;
	
	@Override
	public List<DeliveryManNote> getAllDeliveryManNote() {
		// TODO Auto-generated method stub
		return DeliveryManNoteRepository.findAll();
	}

	@Override
	public void saveOrUpdate(DeliveryManNote deliverymannote) {
		// TODO Auto-generated method stub
		
		//int note = 0 ;
		//deliverymannote.setIdClientDeliveryNote(id);
		//Delivery Delivery1 = DeliveryRepository.findById((int)id).get();
		//long idm = DeliveryRepository.findByidclientd(id);
		//deliverymannote.setIdDeliveryManNote(idm);
	
		DeliveryManNoteRepository.save(deliverymannote);
		
		 
		
		
	}

	@Override
	public void deleteDeliveryManNote(int id) {
		// TODO Auto-generated method stub
		DeliveryManNoteRepository.deleteById(id);
		
		
	}
	
	@Autowired
    private JavaMailSender JavaMailSender;
	public void notification() throws MessagingException {
		//Calendar currentdate = Calendar.getInstance();
		//currentdate.add(Calendar.DAY_OF_MONTH, -1);
		//Date d1 =currentdate.getTime();
		float note = 5 ;
		//List<Integer> d =DeliveryManNoteRepository.lownotes(note);
		//SimpleMailMessage mail = new SimpleMailMessage();
		MimeMessage message = JavaMailSender.createMimeMessage();
	     
	    MimeMessageHelper mail = new MimeMessageHelper(message, true);
		//for(Integer deliverymannote : d)
		//{
			mail.setTo("mohamed.bensalah@esprit.tn");

			mail.setSubject("Delivery man disabled");
			mail.setText("Hello, these delivery men are not doing well their job.\n Please check them on this file!");
			FileSystemResource file = new FileSystemResource(new File("DisabledDM_.xlsx"));
			mail.addAttachment("Invoice", file);

			JavaMailSender.send(message);
				//deliveryman.setStatutsBank(0);
		//}
				//DeliveryService.saveAll(d);
	}
	
	private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    private List<DeliveryMan> list;
    
    public DeliveryManNoteService(List<DeliveryMan> list) {
        this.list = list;
        workbook = new XSSFWorkbook();
    }
    
    private void writeHeaderLine() {
        sheet = workbook.createSheet("Delivery men banned");
         
        Row row = sheet.createRow(0);
         
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        font.setFontHeight(16);
        style.setFont(font);
         
        createCell(row, 0, "Deliveryman ID", style);      
        createCell(row, 1, "Name", style);       
        createCell(row, 2, "Phone", style);    
       
         
    }
     
    private void createCell(Row row, int columnCount, Object value, CellStyle style) {
        sheet.autoSizeColumn(columnCount);
        Cell cell = row.createCell(columnCount);
        if (value instanceof Integer) {
            cell.setCellValue((Integer) value);
        } else if (value instanceof Boolean) {
            cell.setCellValue((Boolean) value);
        }else {
            cell.setCellValue((String) value);
        }
        cell.setCellStyle(style);
    }
     
    private void writeDataLines() {
        int rowCount = 1;
 
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setFontHeight(14);
        style.setFont(font);
                 
        for (DeliveryMan dm : list) {
            Row row = sheet.createRow(rowCount++);
            int columnCount = 0;
             
            createCell(row, columnCount++,dm.getIdDeliveryMan() , style);
            createCell(row, columnCount++,dm.getNameDeliveryMan() , style);
            createCell(row, columnCount++,dm.getTelDeliveryMan() , style);
            
            
             
        }
    }
     
    public void export(HttpServletResponse response) throws IOException {
        writeHeaderLine();
        writeDataLines();
         
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
         
        outputStream.close();
         
    }

}
