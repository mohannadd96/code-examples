package tn.Dari.ProjetSpring.Services;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tn.Dari.ProjetSpring.Repositories.DeliveryRepository;
import tn.Dari.ProjetSpring.Repositories.DeliveryManRepository;
import tn.Dari.ProjetSpring.entities.Delivery;
import tn.Dari.ProjetSpring.entities.DeliveryMan;

@Service
@Transactional
public class DeliveryService implements DeliveryImp {

	@Autowired 
	DeliveryRepository DeliveryRepository;
	@Autowired 
	DeliveryManRepository DeliveryManRepository;
	@Override
	public List<Delivery> getAllDelivery() {
		// TODO Auto-generated method stub
		return DeliveryRepository.findAll();
	}

	@Override
	public Delivery getByid(int id) {
		// TODO Auto-generated method stub
		return DeliveryRepository.findById(id).get();
	}

	@Override
	public void saveOrUpdate(Delivery delivery) {
		
		Date d= new Date(System.currentTimeMillis());
		delivery.setEtatDelivery(false);
		delivery.setDateDelivery(d);
		DeliveryRepository.save(delivery);
	}

	@Override
	public void deleteDelivery(int id) {
		// TODO Auto-generated method stub
		DeliveryRepository.deleteById(id);
	}

	@Override
	public Delivery updateDelivery(int id, Delivery delivery) {
		// TODO Auto-generated method stub
		Delivery Delivery1 = DeliveryRepository.findById(id).get();
		Delivery1.setAddressDelivery(delivery.getAddressDelivery());
		
		return DeliveryRepository.save(Delivery1);
	}

	@Override
	public void affect(int idd, int id) {
		DeliveryMan dm = DeliveryManRepository.findById(id).get();
		Delivery d=DeliveryRepository.findById(idd).get();
		d.setDeliveryMan(dm);
		 DeliveryRepository.save(d);
	}
	
	
	public void affect2() {
		 
		
		 List<DeliveryMan> dm = DeliveryManRepository.findAll();
		 List<Delivery> d = DeliveryRepository.findAll();
		//if((DeliveryRepository.nbr(iddm)<3))
		//{
		// int i=0;
		 
		 for (Iterator<Delivery> il = d.iterator(); il.hasNext();)
		 {
			 Delivery dd= il.next();
	        for (Iterator<DeliveryMan> it = dm.iterator(); it.hasNext();)
		// for(int i = 0 ; i < dm.size(); i++)
		 {
	       
			DeliveryMan dmm =  it.next();
			
			
			if(dmm.getCityDeliveryMan().equals(dd.getAddressDelivery()))
			{
				if(dd.getEtatDelivery())
				{
				dd.setDeliveryMan(dmm);
				}
			}
			
			DeliveryRepository.save(dd);
			 
		 }
		  
		 }
		 
	}

	@Override
	public void checkDelivery(int id) {
		// TODO Auto-generated method stub
		int fees = 0;
		Delivery d=DeliveryRepository.findById(id).get();
		if(d.getAddressDelivery().equals("Tunis"))
		{
			fees = 12 ;
			}
		else if (d.getAddressDelivery().equals("Sousse"))
		{
			fees = 20 ;
			}
		else if (d.getAddressDelivery().equals("Monastir"))
		{
			fees = 30 ;
			}
		else if (d.getAddressDelivery().equals("Kef"))
		{
			fees = 25 ;
			}
		else if (d.getAddressDelivery().equals("Sfax"))
		{
			fees = 75 ;
			}
		else if (d.getAddressDelivery().equals("Gafsa"))
		{
			fees = 80 ;
			}
		else if (d.getAddressDelivery().equals("Tataouin"))
		{
			fees = 100 ;
			}
		d.setFeesDelivery(fees);
		d.setEtatDelivery(true);
		DeliveryRepository.save(d);
	}
	
	@Autowired
    private JavaMailSender JavaMailSender;
	
	public void notification() {
		Calendar currentdate = Calendar.getInstance();
		currentdate.add(Calendar.DAY_OF_MONTH, -1);
		Date d1 =currentdate.getTime();
		List<Delivery> d =DeliveryRepository.findByDatefinlist(d1);
		SimpleMailMessage mail = new SimpleMailMessage();
		for(Delivery delivery : d)
		{
			mail.setTo(delivery.getEmailDelivery());

			mail.setSubject("Delivery service");
			mail.setText("Hello, please fill this form.\n "
			        		+ 
		        		"Click here : https://docs.google.com/forms/d/1Iw9uYoVqkfn-6AR3Zv09oIJPV8Ho4e8eYPyYropiCQk/edit"
		        		+ " \n Best Regards!");

			JavaMailSender.send(mail);
				//delivery.setStatutsBank(0);
		}
				//DeliveryService.saveAll(d);
	}
	
}
