package tn.Dari.ProjetSpring.Services;

import java.util.List;

import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.Wishlist;

public interface WishlistServiceImp {
	public List<Wishlist> getAllWishlist();
	public  Wishlist getByid(Long id);
	public Wishlist saveWishlist(Wishlist wishlist, long id,long idUser);
	public String deleteWishlist(Long id,Long idUser);
	public Wishlist updateWishlist(Long id, Wishlist wishlist);
	public List<Product> ClientWishlist(Long id);

}
