package tn.Dari.ProjetSpring.Services;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import tn.Dari.ProjetSpring.Repositories.AssuranceRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.entities.Asssurance;
import tn.Dari.ProjetSpring.entities.User;
@Service
@Transactional
public class AssuranceService implements IAssuranceService  {
@Autowired
AssuranceRepository ar;
@Autowired
UserRepository ur;
@Autowired
HttpSession session;
	@Override
	public Asssurance addAssurance (Asssurance assurance) {
		Long named=(Long)session.getAttribute("name");	 
		User a=ur.findById(named).get();
				 assurance.setUser(a);
				 return assurance= ar.save(assurance);



	}
	@Override
	public Asssurance updateAssurance(Long id, Asssurance assurance) {
		Asssurance assurance1 = ar.findById(id).get();

	assurance1.setNameAssurance(assurance.getNameAssurance());
		 	assurance1.setAdressAssurance(assurance.getAdressAssurance());
		 	assurance1.setTypeAssurance(assurance.getTypeAssurance());
		return ar.save(assurance1);


		
	}
	@Override
	public ResponseEntity<?> deleteAssurance(Long id) {


			ar.delete( ar.findById(id).get());
			return new ResponseEntity<>("Assurance Deleted successfully", HttpStatus.CREATED);

	}
	@Override
	public List<Asssurance> getAllAssurance() {
		return (List<Asssurance>) ar.findAll();
	}
	@Override
	public List<Asssurance> findByName(String name) {		
		return (List<Asssurance>) ar.findByNameAssurance(name);
	}


}
