package tn.Dari.ProjetSpring.Services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import tn.Dari.ProjetSpring.Repositories.CartRepository;
import tn.Dari.ProjetSpring.Repositories.ProductRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.entities.Cart;

import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.User;

@Service
@Transactional
public class CartService implements CartServiceImp {
	@Autowired
	CartRepository CartRepositroy;
	@Autowired
	ProductRepository ProductRepositroy;
	@Autowired
	UserRepository UserRepositroy;

	@Override
	public List<Cart> getAllCart() {
		// TODO Auto-generated method stub
	
		
		return (List<Cart>)CartRepositroy.findAll();
		
	}
	@Override
	public int SUMPRODUIT(Long id)
	{
		return CartRepositroy.SUMCART(id);
			}
	

	@Override
	public Cart getByid(long id) {
		// TODO Auto-generated method stub
	 return CartRepositroy.findById(id).get();
	}
	public List<Cart> getByUser(long user) {
		// TODO Auto-generated method stub
	 return CartRepositroy.UserItem(user);
	}
	

	@Override
	public void deleteCart(long id) {
		// TODO Auto-generated method stub
		CartRepositroy.deleteById(id);
		
	}
	
	public void SupprimerallCart(long id) {
		// TODO Auto-generated method stub
		CartRepositroy.supprimerCart(id);
		
	}
	public void SupprimerProductFromCart(long id) {
		// TODO Auto-generated method stub
		CartRepositroy.supprimerProductFromCart(id);
		
	}



	@Override
	public Cart saveCart(Cart cart, long id,long idUser) {
		Product product1 = ProductRepositroy.findById(id).get();
	
		
	
		User user= UserRepositroy.UserSaision(idUser);
		cart.setUser(user);
		cart.setPrixCart(product1.getPriceProduct());
		cart.setQuantityProduitPanier(product1.getQuantityProduct());
		Calendar currentDate = Calendar.getInstance();
		Date d = currentDate.getTime();
		cart.setDateCommande(d);
		
			
			cart.setProduct(product1);
			System.out.println(product1.getIdProduct());
			return CartRepositroy.save(cart);
	
	}
	

}
