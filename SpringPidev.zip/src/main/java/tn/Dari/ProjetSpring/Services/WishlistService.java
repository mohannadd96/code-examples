package tn.Dari.ProjetSpring.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tn.Dari.ProjetSpring.Repositories.CartRepository;
import tn.Dari.ProjetSpring.Repositories.ProductRepository;
import tn.Dari.ProjetSpring.Repositories.UserRepository;
import tn.Dari.ProjetSpring.Repositories.WishlistRepository;
import tn.Dari.ProjetSpring.entities.Product;
import tn.Dari.ProjetSpring.entities.User;
import tn.Dari.ProjetSpring.entities.Wishlist;
@Service
@Transactional
public class WishlistService  implements WishlistServiceImp {
	@Autowired
	WishlistRepository WishlistRepositroy;
	@Autowired
	ProductRepository ProductRepositroy;
	@Autowired
	UserRepository UserRepositroy;

	@Override
	public List<Wishlist> getAllWishlist() {
		
	 return WishlistRepositroy.findAll();
	}

	@Override
	public Wishlist getByid(Long id) {
		// TODO Auto-generated method stub
		 return WishlistRepositroy.findById(id).get();
	}

	@Override
	public  Wishlist saveWishlist(Wishlist wishlist, long id,long idUser) {
Product product1 = ProductRepositroy.findById(id).get();
User user1;
user1= UserRepositroy.findById(idUser).get();
		
		wishlist.setUser(user1);
		
wishlist.setProduct(product1);
		System.out.println(product1.getIdProduct());
		return WishlistRepositroy.save(wishlist);
		
	}

	@Override
	public String deleteWishlist(Long id,Long idUser) {
		Product product1 = ProductRepositroy.findById(id).get();
		if (idUser==product1.getUser().getIdUser()){
		
		WishlistRepositroy.supprimerWhislistByUserAndProduct(id,idUser);
		return "Deleted succesfully id= "+id;
		}
		return "id n'existe pas"+id;
	}

	@Override
	public Wishlist updateWishlist(Long id, Wishlist wishlist) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<Product> ClientWishlist(Long idUser)
	{
		return  WishlistRepositroy.WishlistClient(idUser);
			}

}
