package tn.Dari.ProjetSpring.Services;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import tn.Dari.ProjetSpring.entities.Bank;


public interface IBankService {
	
		public Bank addBank(Bank bank);
		public Bank updateBank(Long id,Bank bank);
		public ResponseEntity<?> deleteBank(Long id);
		public List<Bank> getAllBank();
		public Bank check();
		public List<Bank> disable();
		public ResponseEntity<?> enable(Long id);
		
}
