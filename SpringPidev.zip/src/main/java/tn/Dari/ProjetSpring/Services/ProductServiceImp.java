package tn.Dari.ProjetSpring.Services;
import java.util.List;

import tn.Dari.ProjetSpring.entities.Product;

public interface ProductServiceImp {
	public List<Product> getAllProducts();
	public  List<Product> getByid(Long id);
	public void saveOrUpdate(Product product);
	public void deleteProduct(Long id, Long userid);
	public Product updateProduct(Long id,Long idUser, Product product);
	public List<Product> findByName(String name);

}
