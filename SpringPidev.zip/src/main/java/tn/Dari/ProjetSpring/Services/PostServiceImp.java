package tn.Dari.ProjetSpring.Services;

import java.util.List;

import tn.Dari.ProjetSpring.entities.Post;

public interface PostServiceImp {
	public List<Post> getAllPost();
	public  Post getByid(int id);
	public void saveOrUpdate(Post post);
	public void deletePost(int id);
	public Post updatePost(int id, Post postt);
}
