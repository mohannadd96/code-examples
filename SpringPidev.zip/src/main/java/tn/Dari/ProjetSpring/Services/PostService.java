package tn.Dari.ProjetSpring.Services;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tn.Dari.ProjetSpring.Repositories.PostRepository;
import tn.Dari.ProjetSpring.entities.Post;


import tn.Dari.ProjetSpring.entities.Post;
@Service
@Transactional
public class PostService implements PostServiceImp {
@Autowired 
PostRepository PostRepository;
	@Override
	public List<Post> getAllPost() {
		// TODO Auto-generated method stub
		return PostRepository.findAll();
		
	}

	@Override
	public Post getByid(int id) {
		// TODO Auto-generated method stub
		return PostRepository.findById(id).get();
		
	}

	@Override
	public void saveOrUpdate(Post post) {
		// TODO Auto-generated method stub
		Date d= new Date(System.currentTimeMillis());
		post.setDatePost(d);
		PostRepository.save(post);
		
	}

	@Override
	public void deletePost(int id) {
		// TODO Auto-generated method stub
		PostRepository.deleteById(id);
		
	}

	@Override
	public Post updatePost(int id, Post post) {
		// TODO Auto-generated method stub
		Post Post1 = PostRepository.findById(id).get();
	 	Post1.setPricePost(post.getPricePost());
	 	Post1.setDatePost(post.getDatePost());
	 	Post1.setImagePost(post.getImagePost());
	 	Post1.setTypePost(post.getTypePost());
	 	Post1.setNbOfRoomsPost(post.getNbOfRoomsPost());
	 	Post1.setAddressPost(post.getAddressPost());
	 	Post1.setBuildingType(post.getBuildingType());
	 	Post1.setDescriptionPost(post.getDescriptionPost());
	 return PostRepository.save(Post1);
		
	}

}
