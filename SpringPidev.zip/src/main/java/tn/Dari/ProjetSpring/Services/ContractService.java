package tn.Dari.ProjetSpring.Services;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfWriter;

import tn.Dari.ProjetSpring.Repositories.AssuranceRepository;
import tn.Dari.ProjetSpring.Repositories.ContractRepository;
import tn.Dari.ProjetSpring.entities.Asssurance;
import tn.Dari.ProjetSpring.entities.Contract;

@Service
@Transactional
public class ContractService implements IContractService {

	@Autowired
	ContractRepository cr;
	@Autowired
	AssuranceRepository ar;

	
	@Override
	public Contract addContract(Contract contract, Long id) {
		Asssurance assurance1 = ar.findById(id).get();
		Calendar currentDate = Calendar.getInstance();
		Date d = currentDate.getTime();
		contract.setDateStartContract(d);
		currentDate.setTime(d);
		currentDate.add(Calendar.MONTH, 3);
		Date d1 = currentDate.getTime();
		contract.setDateEndContract(d1);
		System.out.println(d1);
		contract.setAssurance(assurance1);	
		return cr.save(contract);
	}

	@Override
	public List<Contract> getAllContract() {
		return (List<Contract>) cr.findAll();
	}

	@Override
	public ResponseEntity<?> generateContract(Long id) throws IOException, URISyntaxException, DocumentException {
		Contract c=cr.findById(id).get();
		
		Font redFont = FontFactory.getFont(FontFactory.COURIER, 20, Font.BOLD, new CMYKColor(0, 255, 0, 0));
		Font whiteFont = FontFactory.getFont(FontFactory.COURIER, 18, Font.BOLD, new CMYKColor(255, 255, 255, 255));
		Document document = new Document();
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Contract.pdf"));
			document.open();
			Image img = Image.getInstance("C:\\Users\\MSI\\Desktop\\DATA\\pi\\pres\\Dari.png");
			img.setAbsolutePosition(450, 760);
			img.scaleToFit(150, 80);
			document.add(img);
			//Paragraph with color and font styles
			Paragraph paragraphOne = new Paragraph("				 					Contract client \n \n \n \n", redFont);
			document.add(paragraphOne);

			//Create chapter and sections
	
			Paragraph chapterTitle = new Paragraph("Id contract "+c.getIdContract()+" \n \n", redFont);;
			Paragraph p=new Paragraph("this is a contract for the insurance of type "+c.getAssurance().getTypeAssurance()+" for the physical person of the name"
					+ " for the price "+c.getPriceContract()+" that started the "+c.getDateStartContract()+" and ended the "+c.getDateEndContract()+"\n\n\n\n\n\n\n\n",whiteFont);
			Paragraph p1 =new Paragraph("                                                                                                      signature");
			Paragraph p2 =new Paragraph("                                                                                                     ---------------");
			document.add(chapterTitle);
			document.add(p);
			document.add(p1);
			document.add(p2);
			document.close();
			writer.close();
			return new ResponseEntity<>("Contract Downloaded successfully", HttpStatus.CREATED);
	}
	}
	
	
