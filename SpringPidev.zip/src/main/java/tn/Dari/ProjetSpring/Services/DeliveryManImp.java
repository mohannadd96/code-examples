package tn.Dari.ProjetSpring.Services;

import java.util.List;

import tn.Dari.ProjetSpring.entities.DeliveryMan;
import tn.Dari.ProjetSpring.entities.Post;

public interface DeliveryManImp {
	public List<DeliveryMan> getAllDeliveryMan();
	public  DeliveryMan getByid(int id);
	public void saveOrUpdate(DeliveryMan deliveryman);
	public void deleteDeliveryMan(int id);
	public DeliveryMan updateDeliveryMan(int id, DeliveryMan deliveryman);
}
