package tn.Dari.ProjetSpring.Services;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tn.Dari.ProjetSpring.Repository.AbonnementRep;
import tn.Dari.ProjetSpring.Repository.UserRep;
import tn.Dari.ProjetSpring.entities.Abonnement;
import tn.Dari.ProjetSpring.entities.User;

@Service
@Transactional
public class AbonnementService implements IAbonnementService {
	
	@Autowired
	AbonnementRep ab;
	@Autowired
	UserRep userRepository;
	@Autowired
	HttpSession session;

	@Override
	public Abonnement addAbonnement(Abonnement abonnement) {
		// TODO Auto-generated method stub
		Long id=(Long)session.getAttribute("name");	 
		User pu = userRepository.findById(id).get();
		//pu.setRole(2);
		//userRepository.save(pu);
		userRepository.addrole(pu.getIdUser(),3);
		abonnement.setPremiumuser(pu);
		return ab.save(abonnement);
		
	}

	@Override
	public void deleteAbonnement(Long id) {
		// TODO Auto-generated method stub
		ab.deleteById(id);
	}

	@Override
	public List<Abonnement> showAbonnement() {
		// TODO Auto-generated method stub
		return (List<Abonnement>) ab.findAll();
	}

	@Override
	public Optional<Abonnement> showAbonnementbyid() {
		Long id=(Long)session.getAttribute("name");	
		return ab.findById(id);
	}

}