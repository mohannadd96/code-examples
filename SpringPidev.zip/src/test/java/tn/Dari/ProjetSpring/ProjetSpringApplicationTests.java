package tn.Dari.ProjetSpring;
import tn.Dari.ProjetSpring.Repositories.ProductRepository;
import tn.Dari.ProjetSpring.entities.Product;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetSpringApplicationTests {
	@Autowired
	private ProductRepository ProductRepository;

	@Test
	public void testerAjoutProduct(){
		//Product prod =new Product("Mickey Mouse","Mickey Mouse",30,30, new Date(),"Mickey Mouse");
		// ProductRepository.save(prod);
		
	}
	

}
