export class Comment {
    rating: number;
    comment: string;
    author: string;
    date: string;
}

export const CommentType = ['rating', 'comment', 'author', 'date'] ;