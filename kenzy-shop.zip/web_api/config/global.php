<?php

return [
	'ProductImage' => "http://localhost:8000/images/"
	

];