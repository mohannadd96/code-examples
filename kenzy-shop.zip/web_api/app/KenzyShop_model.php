<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;

class KenzyShop_model extends Model
{
    public function AllProductList()
    {
        $result = DB::select('SELECT * from ad_tbl');
        return $result;
    }
    public function ProductDetail($id)
    {
        $result = DB::select('SELECT * from ad_tbl WHERE id = ?',[$id]);
        return $result;   
    }
    // public function OtpLog($phone,$otp,$date_time)
    // {
    //   $result = DB::insert('INSERT INTO tblotplog(otp,phone,date_time,updatedtimestamp) VALUES (?,?,?,?)',[$otp,$phone,$date_time,'0000-00-00 00:00:00']);
    // }
    // public function SignUp($mobile)
    // {
    //   $result = DB::insert('INSERT INTO tblCustomerUser(c_name,c_email,c_mobile,token,bisremove,is_registered) VALUES (?,?,?,?,?,?)',['0','0',$mobile,'0','0','0']);
    // }
    // public function AddOrderMaster($total_amount,$payment_id,$restaurant_id,$c_id,$order_code,$tax,$table_no,$net_amount,$date_time)
    // {
    //   $result = DB::insert('INSERT INTO tblOrderMaster(resturant_id,order_code,total_amount,tax,table_no,net_amount,payment_id,c_id,date_time) VALUES (?,?,?,?,?,?,?,?,?)',[$restaurant_id,$order_code,$total_amount,$tax,$table_no,$net_amount,$payment_id,$c_id,$date_time]);
    //    $id = DB::getPDO()->lastInsertId();

    //   return $id; 
    // }
    // public function AddOrder($order_last_id,$dishid,$quentity,$unit_price,$date_time)
    // {
    //   $result = DB::insert('INSERT INTO tblOrder(order_id,dish_id,quentity,unit_price,date_time) VALUES (?,?,?,?,?)',[$order_last_id,$dishid,$quentity,$unit_price,$date_time]);
    //    $id = DB::getPDO()->lastInsertId();

    //   return $id; 
    // }
    // public function AddAddon($dish_last_id,$addonid,$quentity,$unit_price)
    // {
    //   $result = DB::insert('INSERT INTO tblOrerAddon(dish_odder_id,addon_id,quentity,unit_price) VALUES (?,?,?,?)',[$dish_last_id,$addonid,$quentity,$unit_price]);
    //    return $result; 
    // }
    // public function OrderMasterList($c_id)
    // {
    //   $result = DB::select('SELECT * from tblOrderMaster where c_id = ? ORDER BY order_id DESC',[$c_id]);
    //   return $result;
    // }
    // public function OrderdDetail($order_id)
    // {
    //   $result = DB::select('SELECT * from tblOrderMaster where order_id = ? ORDER BY order_id DESC',[$order_id]);
    //   return $result;
    // }
    // public function OrderdishList($order_id)
    // {
    //   $result = DB::select('SELECT * from tblOrder where order_id = ? ORDER BY order_id DESC',[$order_id]);
    //   return $result;
    // }
    // public function OrderAddonList($dish_odder_id)
    // {
    //   $result = DB::select('SELECT * from tblOrerAddon where dish_odder_id = ? ORDER BY dish_odder_id DESC',[$dish_odder_id]);
    //   return $result;
    // }
    // public function AddonListUsingDishType($dish_id)
    // {
    //   $result = DB::select('SELECT * from tblRestaurantAddon where bisremove = ? AND dish_id = ? ORDER BY addon_name ASC',['0',$dish_id]);
    //   return $result;
    // }
    // public function RestaurantFoodDishDetail($dishid)
    // {
    //   $result = DB::select('SELECT * from tblRestaurantFoodDishes where dish_id = ?',[$dishid]);
    //   return $result;
    // }
    // public function RestaurantFoodDishUsingType($food_type_id)
    // {
    //   $result = DB::select('SELECT * from tblRestaurantFoodDishes where bisremove = ?  AND food_type_id = ? AND is_veg = ? ORDER BY dish_name ASC',['0',$food_type_id,'1']);
    //   return $result;
    // }
    // public function ResurantDetail($resaturantid)
    // {
    //   $result = DB::select('SELECT tblRestaurantData.restaurantid as restaurantid,tblRestaurantData.userid as userid,tblRestaurantData.restaurant_image as restaurant_image,tblRestaurantData.owner_name as owner_name,tblRestaurantData.restaurant_phone as restaurant_phone,tblRestaurantData.restaurant_phone1 as restaurant_phone1,restaurant_address,cities.city_name as city_name,cities.city_id AS city_id,states.state_code as state_code,states.state_name AS state_name,country.id AS country_id,country.country_name AS country_name FROM tblRestaurantData INNER JOIN cities ON cities.city_id = tblRestaurantData.city INNER JOIN states ON states.state_code = tblRestaurantData.state  INNER JOIN country ON country.id = tblRestaurantData.country  where restaurantid = ?',[$resaturantid]);
    //   return $result;
    // }
    // public function UserdetailId($userid)
    // {
    //   $result = DB::select('SELECT * from tblUserAdmin where id = ?',[$userid]);
    //   return $result;
    // }

    // public function RestaurantAddonDetail($addon_id)
    // {
    //   $result = DB::select('SELECT * from tblRestaurantAddon where  addon_id = ?',[$addon_id]);
    //   return $result;
    // }
    // public function Otpverify($phone)
    // {
    //   DB::update('UPDATE tblUser set is_verify = ? where mobile = ?',['1',$phone]);
    // }
    // public function UpdateProfile($mobile,$email,$name)
    // {
    //   DB::update('UPDATE tblCustomerUser set c_name = ?,c_email = ?,is_registered = ? where c_mobile = ?',[$name,$email,'1',$mobile]);
    // }
    // public function UpdateCustomerNumber($mobile,$token)
    // {
    //   DB::update('UPDATE tblCustomerUser set  c_mobile = ? where token = ?',[$mobile,$token]);
    // }
    
    // public function UpdateToken($token,$phone)
    // {
    //   DB::update('UPDATE tblCustomerUser set token = ? where c_mobile = ?',[$token,$phone]);
    // }
    // public function CustomerDetail($phone)
    // {
    //   $result = DB::select('SELECT * from tblCustomerUser where c_mobile = ?',[$phone]);
    //   return $result;
    // }
    // public function CustomerDetailUsingToken($token)
    // {
    //   $result = DB::select('SELECT * from tblCustomerUser where token = ?',[$token]);
    //   return $result;
    // }
    
    // public function GenerateToken($length = 16)
    // {
    //   $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    //   $charactersLength = strlen($characters);
    //   $randomString = '';
    //   for ($i = 0; $i < $length; $i++) 
    //     {
    //          $randomString .= $characters[rand(0, $charactersLength - 1)];
    //     }
    //   return $randomString;
    // }
    // public function GetOtp($phone)
    // {
    //   $result = DB::select('SELECT * from tblotplog where phone = ? ORDER BY id DESC LIMIT 1',[$phone]);
    //   return $result;
    // }
    // public function GetCountry()
    // {
    // 	$result = DB::select('SELECT * from country');
    // 	return $result;
    // }
    // public function GetState($country_id)
    // {
    // 	$result = DB::select('SELECT * from states where country_code = ?',[$country_id]);
    // 	return $result;
    // }
    // public function RestaurantFoodTypeList($restaurantid)
    // {
    //   $result = DB::select('SELECT * from tblRestaurantFoodType where bisremove = ? AND restaurantid = ? ORDER BY food_type ASC',['0',$restaurantid]);
    //   return $result;
    // }


    // public function dateDiff($time1, $time2, $precision = 6)
    // {
    //   if (!is_int($time1)) 
    //     {
    //       $time1 = strtotime($time1);
    //     }
    //     if (!is_int($time2))
    //     {
    //       $time2 = strtotime($time2);
    //     }
    //     if ($time1 > $time2)
    //     {
    //         $ttime = $time1;
    //         $time1 = $time2;
    //         $time2 = $ttime;
    //     }
    //     $intervals = array('year','month','day','hour','minute','second');
    //     $diffs = array();
    //     foreach ($intervals as $interval)
    //     {
    //       $ttime = strtotime('+1 ' . $interval, $time1);
    //       $add = 1;
    //       $looped = 0;
    //       while ($time2 >= $ttime)
    //         {
    //           $add++;
    //           $ttime = strtotime("+" . $add . " " . $interval, $time1);
    //           $looped++;
    //         }
    //         $time1 = strtotime("+" . $looped . " " . $interval, $time1);
    //         $diffs[$interval] = $looped;
    //       }
    //       $count = 0;
    //       $times = array();
    //       foreach ($diffs as $interval => $value) 
    //       {
    //           if ($count >= $precision)
    //           {
    //             break;
    //           }
    //           if ($value > 0)
    //           {
    //             if ($value != 1) 
    //             {
    //               $interval .= "s";
    //             }
    //             $times[] = $value;
    //             $count++;
    //           }
    //       }
    //       return $times;
    //     }
}
