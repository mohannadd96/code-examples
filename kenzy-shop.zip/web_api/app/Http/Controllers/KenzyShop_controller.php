<?php

namespace App\Http\Controllers;
use App\KenzyShop_model;
use Illuminate\Http\Request;
use Mail;
use Carbon\Carbon;

class KenzyShop_controller extends Controller
{
    public function ProductList(Request $request)
    {
      $KenzyShop = new KenzyShop_model();
      $ProductList = json_decode(json_encode($KenzyShop->AllProductList()), true);

      if(count($ProductList)  == 0){
        $data = array("message"=>"No Data Found");
        $result = array("status"=>"0","data"=>$data);
        return response()->json($result);
      }else{

        $count = 0;

        for($i=0;$i<count($ProductList);$i++)
        {
          $productData = array("id"=>$ProductList[$i]['id'],"category"=>$ProductList[$i]['category'],"image"=>config('global.ProductImage').$ProductList[$i]['image'],"phone"=>$ProductList[$i]['phone'],"place"=>$ProductList[$i]['place'],"price"=>$ProductList[$i]['price'],"status"=>$ProductList[$i]['status'],"text"=>$ProductList[$i]['text'],"title"=>$ProductList[$i]['title'],"type"=>$ProductList[$i]['type']);
          $data[$count] = $productData;
          $count++;
        }

        $result = array("status"=>"1","data"=>$data);
        return response()->json($result);
      }
    
    }
    public function ProductDetail(Request $request, $id)
    {
      $KenzyShop = new KenzyShop_model();
      $ProductList = json_decode(json_encode($KenzyShop->ProductDetail($id)), true); 
      $productData = array("id"=>$ProductList[0]['id'],"category"=>$ProductList[0]['category'],"image"=>config('global.ProductImage').$ProductList[0]['image'],"phone"=>$ProductList[0]['phone'],"place"=>$ProductList[0]['place'],"price"=>$ProductList[0]['price'],"status"=>$ProductList[0]['status'],"text"=>$ProductList[0]['text'],"title"=>$ProductList[0]['title'],"type"=>$ProductList[0]['type'],"created"=>$ProductList[0]['created']);
      $result = array("status"=>"1","data"=>$productData);
      return response()->json($result);     
    }
}
