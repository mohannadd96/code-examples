

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">



<body paddingwidth="0" paddingheight="0" style="padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased;"

  offset="0" toppadding="0" leftpadding="0">

  <table bgcolor="#ffffff" width="100%" border="0" cellspacing="0" cellpadding="0" class="tableContent" align="center" style="font-family:Helvetica, Arial,serif;">

    <tbody>

      <tr>

        <td>

          <table width="600" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#fafafa" class="MainContainer">

            <tbody>

              <tr>

                <td>

                  <table width="100%" border="0" cellspacing="0" cellpadding="0">

                    <tbody>

                      <tr>

                        <td>

                          <table width="100%" border="0" cellspacing="0" cellpadding="0">

                            <tbody>

                              <tr>

                                <td height="20" class="spechide"></td>

                              </tr>

                              <tr>

                                <td class="movableContentContainer " valign="top"></td>

                                <div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;">

                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">

                                    <tbody>

                                      <tr>

                                        <td>

                                          <table width="100%" border="0" cellspacing="0" cellpadding="0">

                                            <tbody>

                                              <tr>

                                                <td align="center">

                                                  <img alt="Thanq Card" src="" width="50%" />

                                                </td>

                                              </tr>

                                            </tbody>

                                          </table>

                                        </td>

                                      </tr>

                                      <tr>

                                        <td height="20" class="spechide"></td>

                                      </tr>

                                    </tbody>

                                  </table>

                                </div>

                                <div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;">

                                  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#26bbaf" align="center" style="padding: 0px 30px;">

                                    <tr>

                                      <td height="25"></td>

                                    </tr>

                                    <tr>

                                      <td align="left">

                                        <div class="contentEditableContainer contentTextEditable">

                                          <div class="contentEditable" align="center">

                                            <!-- <h2>Will this be your welcome email?</h2> -->

                                          </div>

                                        </div>

                                      </td>

                                    </tr>

                                    <tr>

                                      <td height="2"> </td>

                                    </tr>

                                    <tr>

                                      <td align="left">

                                        <div class="contentEditableContainer contentTextEditable">

                                          <div class="contentEditable" align="left">

                                            <h2 style="color: #fff">Thank you,</h2>

                                            <p style="color: #fff">

                                             Your Password 
                                            </p>

                                          </div>

                                        </div>

                                      </td>

                                    </tr>

                                    <tr>

                                      <td height="30"></td>

                                    </tr>

                                    <tr>

                                      <td align="center">

                                        <table>

                                          <tr>

                                            <td align="center">

                                              <div class="contentEditableContainer contentTextEditable">

                                                <div class="contentEditable" align="left">

                                                  <p style="color: #fff;"> 

                                                   <?php print_r($Password)?>

                                                  </p>

                                                </div>

                                              </div>

                                            </td>

                                          </tr>

                                        </table>

                                      </td>

                                    </tr>

                                    <tr>

                                      <td height="27"></td>

                                    </tr>

                                  </table>

                                </div>

                                <div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;">

                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">

                                    <tbody>

                                      <tr>

                                        <td height="25"></td>

                                      </tr>

                                      <tr>

                                        <td>

                                          <table width="100%" border="0" cellspacing="0" cellpadding="0">

                                            <tbody>

                                              <tr>

                                                <td valign="top" width="30" class="specbundle">&nbsp;</td>

                                                <td valign="top" class="specbundle">

                                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">

                                                    <tbody>

                                                      <tr>

                                                        <td valign="top" align="center" style="padding-right: 20px;">



                                                          <a target="_blank" href="https://www.facebook.com/Konzept-Solutions-1495564787406327"><img src="http://reboot.konzeptsolutions.com/images/email/fb.png" width="42" height="42" alt="facebook icon" data-default="placeholder" data-max-width="52" data-customIcon="true"></a>

                                                         <a target="_blank" href="https://www.linkedin.com/company/konzept-solutions/"><img src="http://reboot.konzeptsolutions.com/images/email/in.png" width="42" height="42" alt="Linkedin icon" data-default="placeholder" data-max-width="52" data-customIcon="true"></a>

                                                         

                                                          

                                                        </td>



                                                      </tr>

                                                    </tbody>

                                                  </table>

                                                </td>

                                              </tr>

                                            </tbody>

                                          </table>

                                        </td>

                                      </tr>

                                      <tr>

                                        <td height="25"></td>

                                      </tr>

                                    </tbody>

                                  </table>

                                </div>

                              </tr>

                            </tbody>

                          </table>

                        </td>

                      </tr>

                    </tbody>

                  </table>

                </td>

              </tr>

            </tbody>

          </table>

        </td>

      </tr>

    </tbody>

  </table>

  </td>

  </tr>

  </tbody>

  </table>

</body>



</html>