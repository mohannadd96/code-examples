export const environment = {
  production: true,
  baseUrl: 'https://kenzy.shop/web_api/public'
};
