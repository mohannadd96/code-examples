import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {CommanService} from './comman.service';
import {environment} from '../../environments/environment';
import {Observable} from 'rxjs';
import {tap} from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(
    public http: HttpClient,
    // tslint:disable-next-line:no-shadowed-variable
    public CommanService: CommanService
  ) {

  }

  // tslint:disable-next-line:typedef
  post(endpoint: string, body: any) {
    return this.http.post(`${environment.baseUrl}` + '/' + endpoint, body, {
      observe: 'response'
    }).pipe(tap(res => {
      return res.body;
    }));
  }

  get(resourceurl): Observable<any> {

    return this.http.get<any>(`${environment.baseUrl}` + '/' + resourceurl, {observe: 'response'}).pipe(tap(res => {
      return res.body;
    }));
  }

  put(resourceurl): Observable<any> {

    return this.http.get<any>(`${environment.baseUrl}` + '/' + resourceurl, {observe: 'response'}).pipe(tap(res => {
      return res.body;
    }));
  }

  delete(resourceurl): Observable<any> {

    return this.http.delete<any>(`${environment.baseUrl}` + '/' + resourceurl, {observe: 'response'}).pipe(tap(res => {
      return res.body;
    }));
  }
}
