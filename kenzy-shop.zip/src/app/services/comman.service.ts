import {Injectable} from '@angular/core';
import {ToastrService} from 'ngx-toastr';
import {Router} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CommanService {
  
  constructor(
    private toastr: ToastrService,
    public router: Router,
  ) {
  }
  // tslint:disable-next-line:typedef
  showSuccess(message) {
    this.toastr.success(message, 'Success');
  }

  // tslint:disable-next-line:typedef
  showFailure(message) {
    this.toastr.error(message, 'Opps!');
  }

  // tslint:disable-next-line:typedef
  isvalidEmail(email) {
    const regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regex.test(email);
  }

  // tslint:disable-next-line:typedef
  public checkInt(event) {
    return !(event.keyCode > 31 && (event.keyCode < 48 || event.keyCode > 57));
  }

  // tslint:disable-next-line:typedef
  setDataFromLocal(key, val) {
    localStorage.setItem(key, val);
  }

  // tslint:disable-next-line:typedef
  getDataFromLocal() {
    return JSON.parse(localStorage.getItem('data'));
  }

  // tslint:disable-next-line:typedef
  getDataFromLocalTable() {
    return localStorage.getItem('Table');
  }

  // tslint:disable-next-line:typedef
  setToken(val) {
    localStorage.setItem('token', val);
  }

  // tslint:disable-next-line:typedef
  getToken() {
    return localStorage.getItem('token');
  }

  // tslint:disable-next-line:typedef
  loggedIn() {
    return !!localStorage.getItem('company_id');
    // return localStorage.getItem('company_id') != null && localStorage.getItem('user_id') != null;
  }

  // tslint:disable-next-line:typedef
  logOut() {
    localStorage.clear();
    this.router.navigate(['/']);
  }
}
