import { TestBed } from '@angular/core/testing';

import { AuthHttpRequestInterceptor } from './auth-http-request.interceptor';

describe('AuthHttpRequestInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      AuthHttpRequestInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: AuthHttpRequestInterceptor = TestBed.inject(AuthHttpRequestInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
