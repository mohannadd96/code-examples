import {Injectable} from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor, HttpResponse
} from '@angular/common/http';
import {Observable} from 'rxjs';
import {CommanService} from './comman.service';
import {tap} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthHttpRequestInterceptor implements HttpInterceptor {

  mytokan: any = '';

  constructor(private commonService: CommanService,
              ) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (this.commonService.loggedIn()) {
      this.mytokan = this.commonService.getToken();
    }

    const req = request.clone({
      setHeaders: {
        //'Access-Control-Allow-Origin': '*',
        //'Access-Control-Allow-Methods': '*',
        //'Access-Control-Allow-Headers': 'Authorization, Content-Type',
        Accept : '*/*',
        'Content-Type': 'application/json',
      }
    });
    // @ts-ignore
    return next.handle(req)
      .pipe(tap(event => {
          if (event instanceof HttpResponse) {
            if (event.body.status === '0') {
              this.commonService.showFailure(event.body.message);
            }
            return event;
          }
        },
        err => {
          let message = '';
          console.log(err);
          console.log(err.error.message);
          if (err.status === 401) {
            message = 'You are not authorised to view this page';
          } else if (err.status === 404) {
            message = 'The requested resource could not be found';
          } else if (err.status === 500) {
            message = 'Internal Server error';
          } else if (err.status === 422) {
            if (err.error.errors.email) {
              message = err.error.errors.email[0];
            } else if (err.error.errors.mobile) {
              message = err.error.errors.mobile[0];
            } else if (err.error.errors.empId) {
              message = err.error.errors.empId[0];
            }
          } else {
            message = 'Error connecting to server';
          }
          this.commonService.showFailure(message);

          if (err.status === 401) {
            this.commonService.logOut();
          }

          return err.status;
        }
      ));
  }
}
