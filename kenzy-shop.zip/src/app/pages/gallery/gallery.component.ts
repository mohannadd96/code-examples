import { Component, OnInit } from '@angular/core';
import {CommanService} from '../../services/comman.service';
import {ApiService} from '../../services/api.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {
  public loading = false;
  DataStatus: boolean=false;
  products:any = [];
  response:any;
  constructor(
    public commanService: CommanService,
    public apiService: ApiService,
    public routing: Router
  ) { }

  ngOnInit(){
    this.ProductList();
  }
  ProductList(){
    this.loading = true;
    this.response = this.apiService.post('ProductList', {});
    this.response.subscribe((res) => {
      this.loading = false;
      if(res.body.status ==='1'){
        this.DataStatus = true;
        this.products = res.body.data;
        console.log(this.products);
      }else{
        this.DataStatus = false;
        this.commanService.showFailure(res.body.data.message);
      }
    }, () => {
      this.DataStatus = false;
      this.loading = false;
    });
  }
}
