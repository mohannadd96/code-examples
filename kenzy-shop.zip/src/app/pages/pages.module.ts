import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PagesRoutingModule } from './pages-routing.module';
import { PagesComponent } from './pages.component';
import { HomeComponent } from './home/home.component';
import { GalleryComponent } from './gallery/gallery.component';
import { DetailComponent } from './detail/detail.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgxLoadingModule} from 'ngx-loading';
@NgModule({
  declarations: [PagesComponent, HomeComponent, GalleryComponent, DetailComponent],
  imports: [
    CommonModule,
    PagesRoutingModule,
    NgxLoadingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class PagesModule { }
