import { Component, OnInit } from '@angular/core';
import {CommanService} from '../../services/comman.service';
import {ApiService} from '../../services/api.service';
import {Router, ActivatedRoute, Params} from '@angular/router';
@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  public loading = false;
  product:any = [];
  id:any;
  response:any;
  constructor(
    public commanService: CommanService,
    public apiService: ApiService,
    public routing: Router,
    public activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe(params => {
      this.id = params['id']; 
    });
    this.ProductDetail(this.id);
  }
  ProductDetail(id ?: any){
    this.loading = true;
    this.response = this.apiService.get('ProductDetail/' + id);
    this.response.subscribe((res) => {
      this.loading = false;
      if(res.body.status ==='1'){
        this.product = res.body.data;
        console.log(this.product);
      }else{
        this.commanService.showFailure(res.body.data.message);
      }
    }, () => {
      this.loading = false;
    });
  }
}
